package com.example.testgrocery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
