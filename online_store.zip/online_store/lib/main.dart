import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:online_store/consts/theme_data.dart';
import 'package:online_store/inner_screens/categories_feeds.dart';
import 'package:online_store/inner_screens/product_details.dart';
import 'package:online_store/provider/cart_provider.dart';
import 'package:online_store/provider/dark_theme_provider.dart';
import 'package:online_store/provider/favs_provider.dart';
import 'package:online_store/provider/orders_provider.dart';
import 'package:online_store/provider/products.dart';
import 'package:online_store/screens/auth/forget_password.dart';
import 'package:online_store/screens/auth/login.dart';
import 'package:online_store/screens/auth/sign_up.dart';
import 'package:online_store/screens/bottom_bar.dart';
import 'package:online_store/screens/landing_page.dart';
import 'package:online_store/screens/orders/order.dart';
import 'package:online_store/screens/user_info.dart';
import 'package:online_store/screens/user_state.dart';
import 'package:online_store/screens/wishlist/wishlist.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'inner_screens/brands_navigation_rail.dart';
import 'screens/carts/cart.dart';
import 'screens/feeds.dart';
import 'package:online_store/screens/upload_product_form.dart';
import 'package:online_store/screens/main_screen.dart';


void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  DarkThemeProvider themeChangeProvider = DarkThemeProvider();

  void getCurrentAppTheme() async {
    themeChangeProvider.darkTheme =
        await themeChangeProvider.darkThemePreferences.getTheme();
  }

  @override
  void initState() {
    getCurrentAppTheme();
    super.initState();
  }

  final Future<FirebaseApp> _initialization = Firebase.initializeApp();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Object>(
      future: _initialization,
      builder: (context, snapshot) {

        if(snapshot.connectionState==ConnectionState.waiting) {
          return MaterialApp(
            home: Scaffold(
              body: Center(child: CircularProgressIndicator(),)
            ),
          );
        }
        else if (snapshot.hasError) {
          MaterialApp(
            home: Scaffold(
                body: Center(child: Text('Error Occured'),
                )
            ),
          );
        }

        return MultiProvider(
            providers: [
              // StreamProvider<List<BlogPost>>(
              //   initialData: [],
              //   create: (context) => blogPosts(),
              // ),

              // ChangeNotifierProvider(create: (_) => UserInfo(),),

              ChangeNotifierProvider(create: (_) {
                return themeChangeProvider;
              }),
              ChangeNotifierProvider(create: (_) => Products(),),
              ChangeNotifierProvider(create: (_) => CartProvider(),),
              ChangeNotifierProvider(create: (_) => FavsProvider(),),
              ChangeNotifierProvider(create: (_) => OrdersProvider(),),
            ],
            child:
                Consumer<DarkThemeProvider>(builder: (context, themeData, child) {
              return MaterialApp(
                title: 'Flutter Demo',
                theme: Styles.themeData(themeChangeProvider.darkTheme, context),
                home: UserState(),
                //initialRoute: '/',
                routes: {
                  //   '/': (ctx) => LandingPage(),
                  BrandNavigationRailScreen.routeName: (ctx) => BrandNavigationRailScreen(),
                  CartScreen.routeName: (ctx) => CartScreen(),
                  Feeds.routeName: (ctx) => Feeds(),
                  WishlistScreen.routeName: (ctx) => WishlistScreen(),
                  CategoriesFeedsScreen.routeName: (ctx) => CategoriesFeedsScreen(),
                  ProductDetails.routeName: (ctx) => ProductDetails(),
                  LoginScreen.routeName: (ctx) => LoginScreen(),
                  SignUpScreen.routeName: (ctx) => SignUpScreen(),
                  BottomBarScreen.routeName: (ctx) => BottomBarScreen(),
                  UploadProductForm.routeName: (ctx) => UploadProductForm(),
                  ForgetPassword.routeName: (ctx) => ForgetPassword(),
                  OrderScreen.routeName: (ctx) => OrderScreen(),
                  UserInfo.routeName: (ctx) => UserInfo(),
                },
              );
            }));
      }
    );
  }
}
