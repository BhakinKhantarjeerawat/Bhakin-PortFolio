import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class OrderAttr with ChangeNotifier {
  final String orderId;
  final String userId;
  final String productId;
  final String title;
  final String price;
  final String quantity;
  final Timestamp orderDate;
  final String imageUrl;

  OrderAttr({this.orderId, this.userId, this.productId, this.title, this.price,
    this.imageUrl, this.quantity, this.orderDate});

}