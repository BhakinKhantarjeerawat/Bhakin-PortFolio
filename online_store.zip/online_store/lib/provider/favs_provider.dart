import 'package:flutter/cupertino.dart';
import 'package:online_store/models/cart_attr.dart';

class FavsProvider with ChangeNotifier {
  Map<String, FavsAttr> _favsItems = {};

  Map <String, FavsAttr> get getFavsItems
  {
    return {..._favsItems};
  }


  void addAndRemoveFromFav(String productId, double price, String title, String imageUrl) {
    if(_favsItems.containsKey(productId)){
      //TODO: later
      removeItem(productId);
    } else {
      _favsItems.putIfAbsent(productId,
              () => FavsAttr(
            //TODO:
            id: DateTime.now().toString(),
            title: title,
            price: price,
            //TODO:
            quantity: 1,
            imageUrl: imageUrl,));
    }
    notifyListeners();
  }


  void removeItem(String productId) {
    _favsItems.remove(productId);
    notifyListeners();
  }


  void clearFav() {
    _favsItems.clear();
    notifyListeners();
  }
}