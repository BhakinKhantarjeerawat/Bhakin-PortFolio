

import 'package:flutter/cupertino.dart';
import 'package:online_store/models/cart_attr.dart';

class CartProvider with ChangeNotifier {
  Map<String, FavsAttr> _cartItems = {};

  Map <String, FavsAttr> get getCartItems
  {
    return {..._cartItems};
  }

  double get totalAmount{
    var total=0.0;
    _cartItems.forEach((key, value) {total+=value.price*value.quantity; });
    return total;
  }

  void addProductToCart(String productId, double price, String title, String imageUrl) {
    if(_cartItems.containsKey(productId)){
      _cartItems.update(productId, (exitingCartItem) => FavsAttr(
        id: exitingCartItem.id,
        productId: exitingCartItem.productId,
        title: exitingCartItem.title,
        price: exitingCartItem.price,
        quantity: exitingCartItem.quantity+1,
        imageUrl: exitingCartItem.imageUrl,
      ));
    } else {
        _cartItems.putIfAbsent(productId,
                () => FavsAttr(
                  //TODO:
          id: DateTime.now().toString(),
          productId: productId,
          title: title,
          price: price,
          //TODO:
          quantity: 1,
          imageUrl: imageUrl,));
    }
    notifyListeners();
  }


  void reduceItemByOne(String productId) {
    if (_cartItems.containsKey(productId)) {
      _cartItems.update(productId, (exitingCartItem) =>
          FavsAttr(
            id: exitingCartItem.id,
            productId: exitingCartItem.productId,
            title: exitingCartItem.title,
            price: exitingCartItem.price,
            quantity: exitingCartItem.quantity - 1,
            imageUrl: exitingCartItem.imageUrl,
          ),);
    }
    notifyListeners();
  }

  void removeItem(String productId) {
    _cartItems.remove(productId);
    notifyListeners();
  }


  void clearCart() {
    _cartItems.clear();
    notifyListeners();
  }
}