import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:online_store/models/order_attr.dart';
import 'package:online_store/models/product.dart';
import 'package:flutter/cupertino.dart';

class OrdersProvider with ChangeNotifier {
  List<OrderAttr> _orders = [];
  List<OrderAttr> get getOrders {
    return [..._orders];
  }

  // List<Product> get popularProducts{
  //   return _products.where((element)=> element.isPopular).toList();
  // }
  //
  // Product findById (String productId) {
  //   return _products.firstWhere((element) => element.id == productId);
  // }
  //
  // List<Product> findByCategory (String categoryName){
  //   List _categoryList = _products.where((element) => element.productCategoryName.toLowerCase().contains(categoryName.toLowerCase())).toList();
  //   return _categoryList;
  // }
  //
  // List<Product> findByBrand (String brandName){
  //   List _categoryList = _products.where((element) => element.brand.toLowerCase().
  //   contains(brandName.toLowerCase())).toList();
  //   return _categoryList;
  // }

  Future<void> fetchOrders() async {
    final FirebaseAuth _auth = FirebaseAuth.instance;
    User _user = _auth.currentUser;
    var _uid = _user.uid;
    print('the user Id is equal to $_uid');

    try{ await FirebaseFirestore.instance
        .collection('order')
        .where('userId', isEqualTo: _uid)
        .get()
        .then((QuerySnapshot ordersSnapshot) {
      _orders.clear();
      ordersSnapshot.docs.forEach((element) {
        // print('element.get(productBrand), ${element.get('productBrand')}');
        _orders.insert(
            0,
            OrderAttr(
              orderId: element.get('orderId'),
              productId: element.get('productId'),
              userId: element.get('userId'),
              price: element.get('price').toString(),
              quantity: element.get('quantity').toString(),
              imageUrl: element.get('imageUrl'),
              title: element.get('title'),
              orderDate: element.get('orderDate'),
            ));
      });
    });}
    catch(error) {
      print('ERROR: $error');
    }
    notifyListeners();
  }

  void clearOrder() {
    _orders.clear();
    notifyListeners();
  }


}



