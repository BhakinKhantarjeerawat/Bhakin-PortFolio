import 'package:flutter/material.dart';
import 'package:online_store/screens/upload_product_form.dart';
import 'package:online_store/screens/landing_page.dart';

import 'bottom_bar.dart';

class MainScreens extends StatelessWidget {
  // const MainScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return PageView(children: [
      BottomBarScreen(),
      UploadProductForm(),
    ],);
  }
}
