import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:online_store/consts/colors.dart';
import 'package:online_store/screens/auth/sign_up.dart';
import 'package:online_store/services/global_method.dart';


import 'auth/login.dart';
import 'bottom_bar.dart';

class LandingPage extends StatefulWidget {
  // const LandingPage({Key? key}) : super(key: key);

  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  AnimationController _animationController;
  Animation<double> _animation;
  List<String> images = [
    // 'https://www.bangkokairblog.com/wp-content/uploads/2019/05/Lampang.jpg',
    'https://www.takemetour.com/amazing-thailand-go-local/wp-content/uploads/2018/09/Chaesorn-Hot-Spring.jpg',
    'https://i.pinimg.com/originals/ff/5f/cf/ff5fcf443acc0fc36c2a23894dbd6b0e.jpg'
  ];
  final FirebaseAuth _auth = FirebaseAuth.instance;
  GlobalMethods _globalMethods = GlobalMethods();
  bool _isLoading = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    images.shuffle();
    _animationController = AnimationController(vsync: this, duration: Duration(seconds: 20),);
    _animation = CurvedAnimation(parent: _animationController, curve: Curves.linear)
    ..addListener(() {setState(() {
      
    });})..addStatusListener((animationStatus) {
      if(animationStatus == AnimationStatus.completed) {
        _animationController.reset();
        _animationController.forward();
      }
      });
    _animationController.forward();
  }
  @override
  void dispose() {
    // TODO: implement dispose
    _animationController.dispose();
    super.dispose();
  }


  Future<void> _googleSignIn() async {
    final googleSignIn = GoogleSignIn();
    final googleAccount = await googleSignIn.signIn();
    if (googleAccount != null ) {
      final googleAuth = await googleAccount.authentication;
      if (googleAuth.accessToken != null && googleAuth.idToken != null) {
      try{
        final authResult = await _auth.signInWithCredential(GoogleAuthProvider.credential(
            idToken: googleAuth.idToken, accessToken: googleAuth.accessToken));
      } catch (error) {
        _globalMethods.authErrorHandle(error.message, context);
      }
      }
    }
  }

  void _loginAnonymously() async {

      setState(() {
        _isLoading = true;
      });

      try {
        await _auth.signInAnonymously();
      } catch (error) {
        _globalMethods.authErrorHandle(error.message, context);
        print('ERROR: ${error}');
      } finally {
        setState(() {
          _isLoading = false;
        });
      }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      children: [
        CachedNetworkImage(
          imageUrl:
            images[0],
          // placeholder: (context, url) => Icon(
          //   Icons.warning,
          //   size: 99,
          // ),
          errorWidget: (context, url, error) => Icon(Icons.error),
          fit: BoxFit.cover,
          height: double.infinity,
          width: double.infinity,
          alignment: FractionalOffset(_animation.value, 0),
        ),
        Container(
          margin: EdgeInsets.only(top: 30),
          width: double.infinity,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Welcome',
                style: TextStyle(fontSize: 40, fontWeight: FontWeight.w600, color: Colors.white),
              ),
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Text(
                  'Welcome To Lampang Online Store',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w400, color: Colors.white),
                ),
              ),
            ],
          ),
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Row(
              children: [
                SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: ElevatedButton(
                    style: ButtonStyle(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                      // side: BorderSide(color: ColorsConsts.backgroundColor),
                    ))),
                    onPressed: () {
                      Navigator.pushNamed(context, LoginScreen.routeName);
                    },
                    child: Text(
                      'Login',
                      style:
                          TextStyle(fontWeight: FontWeight.w500, fontSize: 18),
                    ),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: ElevatedButton(
                    style: ButtonStyle(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                      side: BorderSide(color: Colors.deepOrangeAccent),
                    ))),
                    onPressed: () {
                      Navigator.pushNamed(context, SignUpScreen.routeName);
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Sign up',
                          style:
                              TextStyle(fontWeight: FontWeight.w500, fontSize: 18),
                        ),
                        SizedBox(width: 5,),
                        Icon(Feather.user_plus, size: 18,),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
              ],
            ),
            SizedBox(height: 30),
            Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Divider(
                      color: Colors.white,
                      thickness: 2,
                    ),
                  ),
                ),
                Text('Or continue with', style: TextStyle(color: Colors.white),),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Divider(
                      color: Colors.white,
                      thickness: 2,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                OutlineButton(
                  onPressed: _googleSignIn,
                  shape: StadiumBorder(),
                  // highlightedBorderColor: Colors.red.shade300,
                  borderSide: BorderSide(width: 2, color: Colors.deepOrangeAccent),
                  child: Text('Google +', style: TextStyle(color: Colors.white),),
                ),
                OutlineButton(
                  onPressed: () {
                    // Navigator.pushNamed(context, BottomBarScreen.routeName);
                    _loginAnonymously();
                  },
                  shape: StadiumBorder(),
                  // highlightedBorderColor: Colors.red.shade300,
                  borderSide: BorderSide(width: 2, color: Colors.deepOrangeAccent),
                  child: Text('Signin as guest', style: TextStyle(color: Colors.white),),
                ),
              ],
            ),
            SizedBox(
              height: 40,
            ),
          ],
        ),
      ],
    ));
  }
}
