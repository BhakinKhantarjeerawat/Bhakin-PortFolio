import 'package:online_store/consts/colors.dart';
import 'package:online_store/consts/my_icons.dart';
import 'package:online_store/provider/cart_provider.dart';
import 'package:online_store/provider/orders_provider.dart';
import 'package:online_store/services/global_method.dart';
import 'package:online_store/screens/carts/cart_empty.dart';
import 'package:online_store/screens/carts/cart_full.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'order_empty.dart';
import 'order_full.dart';

// class OrderScreen extends StatelessWidget {
//   static const routeName = '/OrderScreen';
//
//   @override
//   Widget build(BuildContext ctx) {
//     // final cartProvider = Provider.of<CartProvider>(ctx);
//
//     GlobalMethods globalMethods = GlobalMethods();
//     bool isOrder = false;
//
//
//     return isOrder
//         ? Scaffold(body: OrderEmpty())
//         : Scaffold(
//             bottomSheet: checkoutSection(ctx, cartProvider.totalAmount),
//             appBar: AppBar(
//               backgroundColor: Theme.of(ctx).backgroundColor,
//               title: Text('Total Item(s) in Order : ${cartProvider.getCartItems.length}'),
//               actions: [
//                 IconButton(
//                   onPressed: () {
//                     globalMethods.showDialogg(
//                         'Clear order?',
//                       'All items in the order will be cleared.',
//                         () => cartProvider.clearCart(),
//                       ctx);
//                         // cartProvider.clearCart();
//                   },
//                   icon: Icon(MyAppIcons.trash),
//                 )
//               ],
//             ),
//             body: Container(
//               margin: EdgeInsets.only(bottom: 60),
//               child: ListView.builder(
//                   itemCount: cartProvider.getCartItems.length,
//                   itemBuilder: (BuildContext ctx, int index) {
//                     return ChangeNotifierProvider.value(
//                       value: cartProvider.getCartItems.values.toList()[index],
//                       child: CartFull(
//                         productId: cartProvider.getCartItems.keys.toList()[index],
//                         // id: cartProvider.getCartItems.values.toList()[index].id,
//                         // //TODO:
//                         // productId: cartProvider.getCartItems.keys.toList()[index],
//                         // price: cartProvider.getCartItems.values.toList()[index].price,
//                         // title: cartProvider.getCartItems.values.toList()[index].title,
//                         // imageUrl: cartProvider.getCartItems.values.toList()[index].imageUrl,
//                         // quantity: cartProvider.getCartItems.values.toList()[index].quantity,
//                       ),
//                     );
//                   }),
//             ),
//           );
//   }
//
//   Widget checkoutSection(BuildContext ctx, double subtotal) {
//     return Container(
//         decoration: BoxDecoration(
//           border: Border(
//             top: BorderSide(color: Colors.grey, width: 0.5),
//           ),
//         ),
//         child: Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: Row(
//             /// mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Expanded(
//                 flex: 2,
//                 child: Container(
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(30),
//                     gradient: LinearGradient(colors: [
//                       ColorsConsts.gradiendLStart,
//                       ColorsConsts.gradiendLEnd,
//                     ], stops: [
//                       0.0,
//                       0.7
//                     ]),
//                   ),
//                   child: Material(
//                     color: Colors.transparent,
//                     child: InkWell(
//                       borderRadius: BorderRadius.circular(30),
//                       onTap: () {},
//                       splashColor: Theme.of(ctx).splashColor,
//                       child: Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: Text(
//                           'Checkout',
//                           textAlign: TextAlign.center,
//                           style: TextStyle(
//                               color: Theme.of(ctx).textSelectionColor,
//                               fontSize: 18,
//                               fontWeight: FontWeight.w600),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//               Spacer(),
//               Text(
//                 'Total:',
//                 style: TextStyle(
//                     color: Theme.of(ctx).textSelectionColor,
//                     fontSize: 18,
//                     fontWeight: FontWeight.w600),
//               ),
//               Text(
//                 'US \$ ${subtotal.toStringAsFixed(2)}',
//                 //textAlign: TextAlign.center,
//                 style: TextStyle(
//                     color: Colors.blue,
//                     fontSize: 18,
//                     fontWeight: FontWeight.w500),
//               ),
//             ],
//           ),
//         ));
//   }
// }

class OrderScreen extends StatefulWidget {
  static const routeName = '/OrderScreen';

  @override
  _OrderScreenState createState() => _OrderScreenState();
}

class _OrderScreenState extends State<OrderScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // StripeService.init();
  }

  // void payWithCard({int amount}) async {
  //   ProgressDialog dialog = ProgressDialog(context);
  //   dialog.style(message: 'Please wait...');
  //   await dialog.show();
  //   var response = await StripeService.payWithNewCard(
  //       currency: 'USD', amount: amount.toString());
  //   await dialog.hide();
  //   print('response : ${response.message}');
  //   Scaffold.of(context).showSnackBar(SnackBar(
  //     content: Text(response.message),
  //     duration: Duration(milliseconds: response.success == true ? 1200 : 3000),
  //   ));
  // }

  @override
  Widget build(BuildContext context) {
    GlobalMethods globalMethods = GlobalMethods();
    final orderProvider = Provider.of<OrdersProvider>(context);
    // final cartProvider = Provider.of<CartProvider>(context);
    return FutureBuilder<Object>(
      future: orderProvider.fetchOrders(),
      builder: (context, snapshot) {
        return orderProvider.getOrders.isEmpty
            ? Scaffold(body: OrderEmpty())
            : Scaffold(
          appBar: AppBar(
            backgroundColor: Theme.of(context).backgroundColor,
            title: Text('Orders (${orderProvider.getOrders.length})'),
            actions: [
              // IconButton(
              //   onPressed: () {
              //     globalMethods.showDialogg(
              //         'Clear All Orders!',
              //         'Your order will be cleared!',
              //         () => orderProvider.clearOrder(),
              //         context);
              //   },
              //   icon: Icon(MyAppIcons.trash),
              // )
            ],
          ),
          body:
              Container(
                margin: EdgeInsets.only(bottom: 60),
                child: ListView.builder(
                    itemCount: orderProvider.getOrders.length,
                    itemBuilder: (BuildContext context, int index) {
                      //TODO:
                      return  ChangeNotifierProvider.value(
                              value: orderProvider.getOrders[index],
                              child:OrderFull());
                    }),
              )

        );
      }
    );
  }


}

