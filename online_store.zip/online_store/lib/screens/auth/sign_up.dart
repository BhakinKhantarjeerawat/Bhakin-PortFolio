import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:online_store/services/global_method.dart';
import 'package:wave/config.dart';
import 'package:wave/wave.dart';
import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';



class SignUpScreen extends StatefulWidget {
  static const routeName = '/SignUpScreen';

  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final FocusNode _emailFocusNode = FocusNode();
  final FocusNode _passwordFocusNode = FocusNode();
  final FocusNode _phoneNumberFocusNode = FocusNode();

  bool _obscureText = true;
  String _emailAddress = '';
  String _password ='';
  String _fullName ='';
  String _receivingAddress ='';
  int _phoneNumber;
  File _pickedImage;
  final _formKey = GlobalKey<FormState>();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  GlobalMethods _globalMethods = GlobalMethods();
  bool _isLoading = false;
  String url;

  @override
  void dispose() {
    // TODO: implement dispose
    _emailFocusNode.dispose();
    _passwordFocusNode.dispose();
    _phoneNumberFocusNode.dispose();
    super.dispose();
  }

  void _submitForm() async {
    final isValid = _formKey.currentState.validate();
    FocusScope.of(context).unfocus();
    var date = DateTime.now().toString();
    var dateParse = DateTime.parse(date);
    var formattedDate = "${dateParse.day}-${dateParse.month}-${dateParse.year}";

    if (isValid) {

      _formKey.currentState.save();

      try {
        if (_pickedImage==null) {
          _globalMethods.authErrorHandle('Please select an image', context);
        } else {
          //TODO: setState removed here
          setState(() {
            _isLoading = true;
          });
          final ref = FirebaseStorage.instance.ref().child('userImages').child(_fullName+'.jpg');
          await ref.putFile(_pickedImage);
          url = await ref.getDownloadURL();
          await _auth.createUserWithEmailAndPassword(
              email: _emailAddress.toLowerCase().trim(),
              password: _password.trim());
          final User user = _auth.currentUser;
          final _uid = user.uid;
          user.updateProfile(photoURL: url, displayName: _fullName);
          user.reload();
          await FirebaseFirestore.instance.collection('users').doc(_uid).set({
            'id': _uid,
            'name': _fullName,
            'email': _emailAddress,
            'receivingAddress': _receivingAddress,
            'phoneNumber': _phoneNumber,
            'ImageUrl': url,
            'joinedAt': formattedDate,
            'createdAt':Timestamp.now(),
          });
          Navigator.canPop(context) ? Navigator.pop(context) : null;
        }

      } catch (error) {
        _globalMethods.authErrorHandle(error.message, context);
        print('ERROR! ${error}');
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _pickImageCamera() async{
    final picker = ImagePicker();
    final pickedImage = await picker.getImage(source: ImageSource.camera, imageQuality: 10);
    final pickedImageFile = File(pickedImage.path);
    setState(() {
      _pickedImage = pickedImageFile;
    });
    Navigator.pop(context);
  }

  Future<void> _pickImageGallery() async {
    final picker = ImagePicker();
    final pickedImage = await picker.getImage(source: ImageSource.gallery);
    final pickedImageFile = File(pickedImage.path);
    setState(() {
      _pickedImage = pickedImageFile;
    });
    Navigator.pop(context);
  }

  void _remove() {
    setState(() {
      _pickedImage = null;
    });
    Navigator.pop(context);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
          child: Stack(
            children: [

              Container(
                height: MediaQuery.of(context).size.height * 0.95,
                child: RotatedBox(
                  quarterTurns: 2,
                  child: WaveWidget(
                    config: CustomConfig(
                      gradients: [
                        [Colors.red, Color(0xEEF44336)],
                        [Colors.red[800], Color(0x77E57373)],
                        [Colors.orange, Color(0x66FF9800)],
                        [Colors.yellow, Color(0x55FFEB3B)]
                      ],
                      durations: [35000, 19440, 10800, 6000],
                      heightPercentages: [0.20, 0.23, 0.25, 0.30],
                      blur: MaskFilter.blur(BlurStyle.solid, 10),
                      gradientBegin: Alignment.bottomLeft,
                      gradientEnd: Alignment.topRight,
                    ),
                    waveAmplitude: 0,
                    // heightPercentages: [0.25, 0.26, 0.28, 0.31],
                    //TODO: removed network image
                    // backgroundImage: DecorationImage(
                    //   image:
                    //   NetworkImage(
                    //     'https://lh3.googleusercontent.com/proxy/Kygzf64M7PYvXZZiNioB9zxpZIzlmhY1BDONQpecgRjeZ6AEcisyLDA1HQeLZofyvqo1c275cd8JtdzawOoFV1eF5dP0pA5X1ElADvKtAQ',
                    //   ),
                    //   fit: BoxFit.cover,
                    //   colorFilter:
                    //   ColorFilter.mode(Colors.white, BlendMode.softLight),
                    // ),
                    size: Size(
                      double.infinity,
                      double.infinity,
                    ),
                  ),
                ),
              ),

              //TODO:
              Column(
                children: [
                  Stack(
                    children: [
                      Container(margin: const EdgeInsets.symmetric(vertical:30, horizontal: 30),
                      child: CircleAvatar(
                        radius: 71,
                        backgroundColor: Colors.deepOrangeAccent,
                        child: CircleAvatar(
                          radius: 65,
                          backgroundImage: _pickedImage == null ? null
                              :
                          FileImage(_pickedImage),
                        ),
                      ),),
                      Positioned(
                        top:120,
                        left:110,
                        child:RawMaterialButton(
                          elevation:10,
                          fillColor: Colors.red,
                          child: Icon(Icons.add_a_photo),
                          padding: EdgeInsets.all(15),
                          shape:CircleBorder(),
                          onPressed: (){
                            showDialog(
                              context: context,
                              builder:(BuildContext context) {
                                return AlertDialog(
                                  title: Text('Select Options', style: TextStyle(fontWeight: FontWeight.w600,
                                  ),),
                                  content: SingleChildScrollView(
                                    child: ListBody(
                                      children: [
                                        InkWell(
                                          onTap: _pickImageCamera,
                                          splashColor: Colors.purpleAccent,
                                        child: Row(children: [
                                          Icon(Icons.camera, color: Colors.purpleAccent,),
                                          Text(' Camera'),
                                        ],),),
                                        InkWell(
                                          onTap: _pickImageGallery,
                                          splashColor: Colors.purpleAccent,
                                          child: Row(children: [
                                            Icon(Icons.photo, color: Colors.purpleAccent,),
                                            Text(' Gallery')
                                          ],),
                                        ),
                                        InkWell(
                                          onTap: _remove,
                                          splashColor: Colors.purpleAccent,
                                          child: Row(children: [
                                            Icon(Icons.remove_circle, color: Colors.purpleAccent),
                                            Text(' Remove'),
                                          ],)
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              }
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 30,),
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: TextFormField(
                            key: ValueKey('name'),
                            validator: (value) {
                              if(value.isEmpty) {
                                return 'Please enter your name';
                              }
                              return null;
                            },
                            // keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(
                              border: const UnderlineInputBorder(),
                              filled: true,
                              prefix: Icon(Icons.face),
                              labelText: 'name',
                              fillColor: Theme.of(context).backgroundColor,
                            ),
                            onSaved: (value) {
                              _fullName = value;
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: TextFormField(
                            key: ValueKey('email'),
                            validator: (value) {
                              if(value.isEmpty || !value.contains('@')) {
                                return 'Please enter the valid email';
                              }
                              return null;
                            },
                            keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(
                              border: const UnderlineInputBorder(),
                              filled: true,
                              prefix: Icon(Icons.email),
                              labelText: 'Email Address',
                              fillColor: Theme.of(context).backgroundColor,
                            ),
                            onSaved: (value) {
                              _emailAddress = value;
                              print(_emailAddress);
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: TextFormField(
                            key: ValueKey('password'),
                            validator: (value) {
                              if(value.isEmpty) {
                                return 'Please enter the password';
                              }
                              return null;
                            },
                            textInputAction: TextInputAction.next,
                            onEditingComplete: _submitForm,
                            // ()=>FocusScope.of(context).requestFocus(_passwordFocusNode),
                            keyboardType: TextInputType.emailAddress,
                            focusNode: _passwordFocusNode,
                            decoration: InputDecoration(
                                border: const UnderlineInputBorder(),
                                filled: true,
                                prefix: Icon(Icons.lock),
                                suffixIcon: GestureDetector(
                                    onTap: () {
                                      _obscureText=!_obscureText;
                                    },
                                    child: Icon(_obscureText ? Icons.visibility : Icons.visibility_off)),
                                labelText: 'Password',
                                fillColor: Theme.of(context).backgroundColor),

                            onSaved: (value) {
                              _password = value;
                              print(_password);
                            },
                            obscureText: _obscureText,
                          ),
                        ),

                        ////////////////////////////////
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: TextFormField(
                            key: ValueKey('receivingAddress'),
                            validator: (value) {
                              if(value.isEmpty) {
                                return 'Please enter your receivingAddress';
                              }
                              return null;
                            },
                            textInputAction: TextInputAction.next,
                            onEditingComplete: _submitForm,
                            // ()=>FocusScope.of(context).requestFocus(_passwordFocusNode),
                            // keyboardType: TextInputType.number,
                            // focusNode: _phoneNumberFocusNode,
                            decoration: InputDecoration(
                                border: const UnderlineInputBorder(),
                                filled: true,
                                prefix: Icon(Icons.home),
                                // suffixIcon: GestureDetector(
                                //     onTap: () {
                                //       _obscureText=!_obscureText;
                                //     },
                                //     child: Icon(Icons.phone)),
                                labelText: 'receivingAddress',
                                fillColor: Theme.of(context).backgroundColor),

                            onSaved: (value) {
                              _receivingAddress = value;
                            },
                          ),
                        ),
                        ////////////////////
                        ////////////////////

                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: TextFormField(
                            key: ValueKey('phoneNumber'),
                            validator: (value) {
                              if(value.isEmpty) {
                                return 'Please enter your phone number (10 numbers)';
                              }
                              return null;
                            },
                            textInputAction: TextInputAction.next,
                            onEditingComplete: _submitForm,
                            // ()=>FocusScope.of(context).requestFocus(_passwordFocusNode),
                            keyboardType: TextInputType.number,
                            focusNode: _phoneNumberFocusNode,
                            decoration: InputDecoration(
                                border: const UnderlineInputBorder(),
                                filled: true,
                                prefix: Icon(Icons.phone),
                                // suffixIcon: GestureDetector(
                                //     onTap: () {
                                //       _obscureText=!_obscureText;
                                //     },
                                //     child: Icon(Icons.phone)),
                                labelText: 'PhoneNumber',
                                fillColor: Theme.of(context).backgroundColor),

                            onSaved: (value) {
                              _phoneNumber = int.parse(value);
                            },
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: _isLoading
                                  ? CircularProgressIndicator()
                                  :
                                ElevatedButton(
                                style: ButtonStyle(
                                    shape:
                                    MaterialStateProperty.all<RoundedRectangleBorder>(
                                        RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(30.0),
                                          side: BorderSide(color: Colors.deepOrangeAccent),
                                        ))),
                                onPressed: () {
                                  _submitForm();
                                },
                                child: Text(
                                  'Signup',
                                  style:
                                  TextStyle(fontWeight: FontWeight.w500, fontSize: 18),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),

            ],
          ),
        )
    );
  }
}
