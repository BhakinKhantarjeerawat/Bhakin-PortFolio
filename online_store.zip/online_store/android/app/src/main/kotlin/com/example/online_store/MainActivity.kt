package com.example.online_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
