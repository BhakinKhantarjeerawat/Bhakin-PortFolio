import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:workos_english/screens/auth/login.dart';
import 'package:workos_english/screens/task_screen.dart';

class UserState extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, userSnapshot) {
        /// No return if, stead if return
            if (userSnapshot.data == null) {
              return Login();
            } else if (userSnapshot.hasData) {
              return TaskScreen();
            } else if (userSnapshot.hasError) {
              return Scaffold(
                  body: Center(child: Text('ERROR!'),));
            } else if (userSnapshot.connectionState == ConnectionState.waiting) {
              return Scaffold(body: Center(child: CircularProgressIndicator()));
            }
            return Scaffold(
                body: Center(child: Text('ERROR!'),));
      }
    );
  }
}
