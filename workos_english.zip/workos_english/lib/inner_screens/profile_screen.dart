import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:workos_english/constants/constant.dart';
import 'package:workos_english/widgets/drawer_widget.dart';
import 'package:url_launcher/url_launcher.dart';

import '../user_state.dart';


class ProfileScreen extends StatefulWidget {
  const ProfileScreen({required this.userID});
  final String userID;

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  final _titleStyle = const TextStyle(fontSize:25, fontWeight: FontWeight.bold, color: Constant.lightBlue);
  final _contentStyle = const TextStyle(fontSize:18, fontWeight: FontWeight.bold, color: Constant.orange);
  bool _isLoading = false;
  /// alternative: String? phoneNumber;
  String phoneNumber = '';
  String email ='';
  String name = '';
  String position = '';
  String FacebookGroup = '';
  String userImage = 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/1024px-No_image_available.svg.png';
  String createdAt = '';
  bool _isSameUser = false;

  @override
  void initState() {
    // TODO: implement initState
    getUserData();
    super.initState();
  }


  void getUserData() async {
    _isLoading = true;
    final DocumentSnapshot userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userID)
        .get();
    if (userDoc == null) {
      return ;
    } else {
      setState((){
        email = userDoc.get('email');
        name = userDoc.get('name');
        position = userDoc.get('position');
        FacebookGroup = userDoc.get('FacebookGroup');
        phoneNumber = userDoc.get('phoneNumber');
        userImage = userDoc.get('userImage');
        Timestamp joinedAtTimestamp = userDoc.get('createdAt');
        var joinedDate = joinedAtTimestamp.toDate();
        createdAt = '${joinedDate.day}-${joinedDate.month}-${joinedDate.year}';
      });
      User? user = _auth.currentUser;
      final _uid = user!.uid;
      setState(() {
        _isSameUser = _uid == widget.userID;
      });
    }
    _isLoading = false;
  }

  @override
  Widget build(BuildContext context) {
    // Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.brown[100],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.brown[100],
      ),
      drawer: DrawerWidget(),
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Card(
              elevation: 9,
              margin: const EdgeInsets.all(30),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: Column(
            children: [
              const SizedBox(height: 50,),
              Text(name, style: _titleStyle),
              const SizedBox(height: 10,),
              Text('สายงาน: $position', style: _contentStyle),
              const SizedBox(height: 10,),
              Text('เข้าร่วมตั้งแต่: $createdAt',style: _contentStyle),
              _dividerWidget(),
              Text('Contact Info',style: _titleStyle),
              const SizedBox(width: 15,),
              _userInfo(title: 'Email: ', content: email),
              _userInfo(title: 'Phone: ', content: phoneNumber),
              _dividerWidget(),
              Text('FacebookGroup Address',style: _titleStyle),
              const SizedBox(height: 5,),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(child: Text(FacebookGroup), onPressed: (){
                  _openFacebookGroup(FacebookGroup);
                },),
              ),
              _isSameUser ? const SizedBox(height: 5,) : _dividerWidget(),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child:
                _isSameUser ? Container() : Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _contactBy(color: Colors.yellow, icon: Icons.message_outlined, fct: () {
                      _openWhatsAppChat();
                    }),
                    _contactBy(color: Colors.blue, icon: Icons.email_outlined, fct: () {
                      _mailTo();
                    }),
                    _contactBy(color: Colors.red, icon: Icons.phone_outlined, fct: () {
                      _callPhoneNumber();
                    }),
                  ],
                ),
              ),
              // !_isSameUser ? _dividerWidget() : Container(),
              // !_isSameUser ? Container() :
              // MaterialButton(
              //     onPressed: (){
              //       _auth.signOut();
              //       Navigator.push(context,
              //       MaterialPageRoute(
              //         builder: (context)=>UserState(),
              //       ));
              //
              //     },
              //     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              //     color: Constant.lightBlue,
              //     child: const Text('Log Out', style: TextStyle(fontSize: 16, color: Colors.white),)
              // ),
            ],),),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                    border: Border.all(width: 2, color: Theme.of(context).scaffoldBackgroundColor),
                    image: DecorationImage(
                      image: NetworkImage(userImage),
                      fit: BoxFit.fill)
                    )
                  ),
              ],),
        ]),
      )
    );
  }

  Widget _dividerWidget() {
    return  Column(children: const [
       SizedBox(height: 11,),
       Divider(thickness: 2,),
       SizedBox(height: 11,),
    ],);
  }

  Widget _userInfo({required String title, required String content}) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Row(
        children: [
          Text(title,style: const TextStyle(
            fontSize: 18,
            fontStyle: FontStyle.normal,
            fontWeight: FontWeight.bold,
            color: Constant.orange,
          )),
          const SizedBox(width: 5,),
          Text(content,style: const TextStyle(
            fontSize: 18,
            fontStyle: FontStyle.normal,
            color: Constant.orange,
          ),
          ),
        ],
      ),
    );
  }

  void _openFacebookGroup(url) async {
    var FacebookUrl = url;
    await launch(url);
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      print('ERROR: URL can not be launched');
      throw 'ERROR: URL SYSTEM NEED REVIEWING';
    }
  }

  void _openWhatsAppChat() async {
    var url = 'https://wa.me.$phoneNumber?text=HELLOWORLD';
    await launch(url);
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      print('ERROR: URL can not be launched');
      throw 'ERROR: URL SYSTEM NEED REVIEWING';
    }
  }

  void _mailTo() async {
    var mailUrl = 'mailto:$email';
    if (await canLaunch(mailUrl)) {
      await launch(mailUrl);
    } else {
      print('ERROR: The specified email can not be launched');
      throw 'ERROR: The specified email NEED REVIEWING';
    }
  }

  void _callPhoneNumber() async {
    var url = 'tel://$phoneNumber';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      print('ERROR: The phone number can not be launched');
      throw 'ERROR: Phone number system NEED REVIEWING';
    }

  }

  Widget _contactBy({required Color color, required IconData icon, required Function fct}) {
    return CircleAvatar(
      radius: 25,
      backgroundColor: color,
      child: CircleAvatar(
        radius: 23,
        backgroundColor: Colors.white,
        child: IconButton(
          icon: Icon(icon),
          color: Colors.green,
          onPressed: (){fct();}, ),
      ),
    );
  }

}
