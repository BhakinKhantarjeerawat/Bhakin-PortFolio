import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import 'package:workos_english/constants/constant.dart';
import 'package:workos_english/screens/task_screen.dart';
import 'package:workos_english/services/global_methods.dart';
import 'package:workos_english/widgets/drawer_widget.dart';

class UploadTask extends StatefulWidget {
  const UploadTask({Key? key}) : super(key: key);

  @override
  _UploadTaskState createState() => _UploadTaskState();
}

class _UploadTaskState extends State<UploadTask> {
  final FirebaseAuth  _auth = FirebaseAuth.instance;

  final TextEditingController _taskCategoryController = TextEditingController(text: 'Choose category');
  TextEditingController _taskTitleController = TextEditingController();
  TextEditingController _taskDescriptionController = TextEditingController();
  TextEditingController _taskRequirementsController = TextEditingController();
  TextEditingController _taskBenefitsController = TextEditingController();
  TextEditingController _deadlineDateController = TextEditingController(text: 'Choose task deadline date');
  TextEditingController _addressController = TextEditingController(text: 'Choose Address');



  final _formKey = GlobalKey<FormState>();
  DateTime? pickedDate;
  bool _isLoading = false;
  Timestamp? deadlineTimestamp;
  File? _imageFile;
  String? _imageUrl;


  @override
  void dispose() {
    _taskCategoryController.dispose();
    _taskTitleController.dispose();
    _taskDescriptionController.dispose();
    _taskRequirementsController.dispose();
    _taskBenefitsController.dispose();
    _deadlineDateController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  void _uploadTask() async {
    final taskID = Uuid().v4();
    User? user = _auth.currentUser;
    final _uid = user!.uid;
    final isValid = _formKey.currentState!.validate();

    if (isValid) {
      if (_deadlineDateController.text == 'Choose task deadline date' ||
          _taskCategoryController.text == 'Choose category' ||
          _addressController.text == 'Choose Address') {
        GlobalMethods.showErrorDialog(error: 'Date, Category, photo, or Address is not selected', context: context);
        return;

      }
      setState((){
        _isLoading = true;
      });
      // final User? user = _auth.currentUser;
      // final _uid = user!.uid;
      final ref = FirebaseStorage.instance.ref().child('userImages').child(taskID+ 'TASK'+'.jpg');
      await ref.putFile(_imageFile!);
      _imageUrl = await ref.getDownloadURL();
      try{await FirebaseFirestore.instance.collection('tasks').doc(taskID).set(
          {
            'taskImage':_imageUrl,
            'taskID':taskID,
            'uploadedBy': _uid,
            'taskTitle': _taskTitleController.text,
            'taskDescription': _taskDescriptionController.text,
            'taskRequirements': _taskRequirementsController.text,
            'taskBenefits': _taskBenefitsController.text,
            'deadlineDate': _deadlineDateController.text,
            'deadlineDateTimestamp': deadlineTimestamp,
            'taskCategory': _taskCategoryController.text,
            'address': _addressController.text,
            'taskComment':[],
            'isDone': false,
            'createdAt': Timestamp.now(),
          }
      );
      await Fluttertoast.showToast(
          msg: "The task has been uploaded.",
          toastLength: Toast.LENGTH_LONG,
          // gravity: ToastGravity.CENTER,
          // timeInSecForIosWeb: 1,
          backgroundColor: Colors.deepOrangeAccent,
          // textColor: Colors.white,
          fontSize: 18.0
      );
      setState((){
        _taskTitleController.clear();
        _taskDescriptionController.clear();
        _taskRequirementsController.clear();
        _taskBenefitsController.clear();
        _taskCategoryController.text = 'Choose category';
        _deadlineDateController.text = 'Choose task deadline date';
        _addressController.text = 'Choose Address';
      });
      } catch (e) {
          GlobalMethods.showErrorDialog(error: e.toString(), context: context);
      } finally {
        setState((){
          _isLoading = false;
          Navigator.push(context, MaterialPageRoute(builder: (context) => TaskScreen()));
        });
      }
    } else {
      print('ERROR: UPLOADING ERROR!');
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.brown[100],
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.brown[100],
      ),
      drawer: DrawerWidget(),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Card(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              const SizedBox(height: 10,),
              const Align(
                alignment: Alignment.center,
                child: Text('ต้องกรอกข้อมูลทุกช่อง',
                  style: TextStyle(color: Constant.orange, fontSize: 25, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(height: 10,),
              const Divider(thickness: 1,),
              const SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Stack(children: [
                    Center(
                      child: SizedBox(
                        width: 100,
                        height: 100,
                        // decoration: BoxDecoration(
                        //   border: Border.all(width: 1, color: Colors.white),
                        //   borderRadius: BorderRadius.circular(16),
                        // ),
                        child: _imageFile == null
                            ? const Icon(Icons.photo, color: Colors.deepOrange,)
                            : Image.file(_imageFile!, fit: BoxFit.fill),
                      ),
                    ),
                    Center(
                      child: InkWell(
                        onTap: () {
                          _showImageDialog();
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            border: Border.all(width: 3, color: Colors.white),
                          ),
                          child: _imageFile == null
                              ? const Icon(
                            Icons.no_photography,
                            color: Colors.white,
                            size: 30,
                          )
                              : const Icon(
                            Icons.edit,
                            color: Colors.white,
                            size: 30,
                          ),
                        ),
                      ),
                    ),
                  ]),
                ),

                Padding(
                padding: const EdgeInsets.all(8.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      ///
                      _textTile(label:'ประเภทงาน*'),
                      _textFormFields(controller: _taskCategoryController,
                        enabled: false,
                        valueKey:'TaskCategory',
                        fct:(){_showTaskCategoryDialog(size: size);},
                        maxLength: 100),
                      ///
                      _textTile(label:'ชื่องาน'),
                      _textFormFields(controller: _taskTitleController,
                        enabled: true,
                        valueKey:'TaskTitle',
                        fct:(){},
                        maxLength: 50),
                      ///
                      _textTile(label:'คำอธิบายงาน'),
                      _textFormFields(controller: _taskDescriptionController,
                        enabled: true,
                        valueKey:'TaskDescription',
                        fct:(){},
                        maxLength: 500),
                      ///
                      ///
                      _textTile(label:'งานต้องการ'),
                      _textFormFields(controller: _taskRequirementsController,
                          enabled: true,
                          valueKey:'TaskRequirements',
                          fct:(){},
                          maxLength: 500),
                      ///
                      ///
                      _textTile(label:'ประโยชน์ที่จะได้'),
                      _textFormFields(controller: _taskBenefitsController,
                          enabled: true,
                          valueKey:'TaskBenefits',
                          fct:(){},
                          maxLength: 500),
                      ///
                      ///
                      _textTile(label:'จังหวัด*'),
                      _textFormFields(controller: _addressController,
                          enabled: false,
                          valueKey:'select Address',
                          fct:(){_showAddressDialog(size: size);},
                          maxLength: 100),
                      ///
                      ///
                      _textTile(label:'ไม่เกิน*'),
                      _textFormFields(controller: _deadlineDateController,
                          enabled: false,
                          valueKey:'Deadline Date',
                          fct:_pickDateDialog,
                          maxLength: 100),

                       Center(
                         child: _isLoading ? CircularProgressIndicator() :
                         MaterialButton(
                            onPressed: ()  {
                              _uploadTask();
                              // Navigator.push(context, MaterialPageRoute(builder: (context) => TaskScreen()));
                            },
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            color: Colors.blue,
                            child: const Text('Upload', style: TextStyle(fontSize: 20, color: Colors.white),)
                      ),
                       ),
                    ],
                  ),
                ),
              ),

            ],),
          ),
        ),
      ),
    );
  }

  void _pickDateDialog() async {
    pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now().subtract(Duration(days: 0)),
      lastDate: DateTime(2100),
    );
    if (pickedDate != null) {
      setState(() {
        _deadlineDateController.text = '${pickedDate!.year}${pickedDate!.month}${pickedDate!.day}';
      // deadlineTimestamp = Timestamp.fromMicrosecondsSinceEpoch(pickedDate!.microsecond);
      deadlineTimestamp = Timestamp.fromDate(pickedDate!);
      }
    );
    }
  }

  _showTaskCategoryDialog({required Size size}) {
    showDialog(context: context, builder: (context)
    {
      return AlertDialog(
        title: const Text('Task Categories'),
        content: SizedBox(
          width: size.width * 0.3,
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: Constant.taskCategoryList.length,
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () {
                    setState( () {
                      _taskCategoryController.text = Constant.taskCategoryList[index];
                    }
                    );
                    Navigator.pop(context);
                  },
                  child: Row(children: [
                    const Icon(Icons.check_circle_rounded, color: Colors.red,),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text(Constant.taskCategoryList[index], overflow: TextOverflow.ellipsis,),
                    ),

                  ],),);
              }
          ),
        ),
        actions: [
          ElevatedButton(child: const Text('Close'), onPressed: () {
            Navigator.canPop(context) ? Navigator.pop(context) : null;
          },),
        ],
      );
    }
    );
  }

  void _showAddressDialog({
    required Size size,
    // required String dialogTitle,
    // required List<String> itemList
  }) {
    showDialog(context: context, builder: (context)
    {
      return AlertDialog(
        title: const Text('เลือกจังหวัด', style: TextStyle(color: Constant.orange),),
        content: SizedBox(
          width: size.width * 0.3,
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: Constant.addressList.length,
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () {
                    print(Constant.addressList[index]);
                    setState((){
                      _addressController.text = Constant.addressList[index];
                      // isFilterEnabled = true;
                    });
                    Navigator.pop(context);
                  },
                  child: Row(children: [
                    Icon(Icons.check_circle_rounded, color: Colors.brown[100],),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        Constant.addressList[index],
                        style: const TextStyle(color: Constant.orange),
                      ),
                    ),

                  ],),);
              }
          ),
        ),
        actions: [
          ElevatedButton(child: const Text('Close'), onPressed: () {
            Navigator.canPop(context) ? Navigator.pop(context) : null;
          },),
        ],
      );
    }
    );
  }

  Widget _textFormFields({
    required String valueKey,
    required TextEditingController controller,
    required bool enabled,
    required Function fct,
    required int maxLength}) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: InkWell(
        onTap: (){fct();},
        child: TextFormField(
          validator: (value) {
            if (value!.isEmpty) {
              return 'Value is missing';
            } else {
              return null;
            }
          },
          controller: controller,
          enabled: enabled,
          key: ValueKey(valueKey),
          maxLength: maxLength,
          maxLines: valueKey == 'TaskDescription' || valueKey == 'TaskBenefits' || valueKey == 'TaskRequirements' ? 5 : 1,
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.brown.shade50,
            enabledBorder: const UnderlineInputBorder(
              borderSide: BorderSide(
                color: Colors.white
              )
            ),
          ),
        ),
      ),
    );
  }

  Widget _textTile({required String label}) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Text(label, style: const TextStyle(fontSize: 20, color: Constant.orange),),
    );
  }

  void _showImageDialog() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
              title: const Text(
                'Please choose an option',
                style: TextStyle(
                    color: Constant.lightBlue, fontWeight: FontWeight.bold),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  InkWell(
                      onTap: () {
                        _getFromCamera();
                      },
                      child: Row(
                        children: const [
                          Icon(Icons.camera, color: Constant.lightBlue),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Camera',
                            style: TextStyle(color: Constant.orange),
                          ),
                        ],
                      )),
                  const SizedBox(
                    height: 25,
                  ),
                  InkWell(
                      onTap: () {
                        _getFromGallery();
                      },
                      child: Row(
                        children: const [
                          Icon(Icons.photo_album, color: Constant.lightBlue),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Gallery',
                            style: TextStyle(color: Constant.orange),
                          ),
                        ],
                      )),
                  const SizedBox(height: 30,),
                  ElevatedButton(
                    child: const Text('Close'),
                    onPressed: (){
                    Navigator.pop(context);
                  } ,),
                ],
              ));
        });
  }

  void _getFromGallery() async {
    PickedFile? pickedFile = await ImagePicker()
        .getImage(source: ImageSource.gallery, maxHeight: 1080, maxWidth: 1080,
      );
    Navigator.pop(context);
    _cropImage(pickedFile!.path);
  }

  void _getFromCamera() async {
    PickedFile? pickedFile = await ImagePicker()
        .getImage(source: ImageSource.camera, maxHeight: 1080, maxWidth: 1080);
    // imageFile = File(pickedFile!.path);
    _cropImage(pickedFile!.path);
    Navigator.pop(context);
  }

  void _cropImage(filePath) async {
    File? croppedImage = await ImageCropper.cropImage(
      aspectRatioPresets: [
        CropAspectRatioPreset.ratio3x2,]
      sourcePath: filePath,
      maxWidth: 1080,
      maxHeight: 1080,
      compressQuality: 25,
    );
    if (croppedImage != null) {
      setState(() {
        _imageFile = croppedImage;
      });
    }
  }

}
