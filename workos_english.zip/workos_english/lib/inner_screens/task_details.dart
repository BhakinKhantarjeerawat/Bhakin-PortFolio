import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:uuid/uuid.dart';
import 'package:workos_english/constants/constant.dart';
import 'package:workos_english/services/global_methods.dart';
import 'package:workos_english/widgets/comment_widget.dart';

class TaskDetails extends StatefulWidget {
  const TaskDetails({required this.uploadedBy, required this.taskID});
  final String uploadedBy;
  final String taskID;

  @override
  _TaskDetailsState createState() => _TaskDetailsState();
}

class _TaskDetailsState extends State<TaskDetails> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final _titleStyle = const TextStyle(
      fontSize: 16, color: Constant.lightBlue, fontWeight: FontWeight.bold);
  final _contentStyle = const TextStyle(color: Constant.orange);
  final TextEditingController _commentController = TextEditingController();
  bool _isCommenting = false;
  /// user
  String? authorName;
  String authorPosition = '';
  String? userImageUrl;
  ///
  String? taskImage;
  String? taskTitle;
  String? taskCategory;
  String? taskDescription;
  String? taskRequirements;
  String? taskBenefits;
  Timestamp? postedDateTimestamp;
  Timestamp? deadlineDateTimestamp;
  String? deadlineDate;
  String? postedDate;
  /// bool type
  bool isDone = false;
  bool _isDeadlineAvailable = false;
  ///
  var createdAt;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getTaskData();
  }

  void getTaskData() async {
    final DocumentSnapshot userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.uploadedBy)
        .get();
    if (userDoc == null) {
      print('ERROR: userDoc == null');
      return;
    } else {
      print('FIREBASE GET userDoc');
      setState(() {
        authorName = userDoc.get('name');
        authorPosition = userDoc.get('position');
        userImageUrl = userDoc.get('userImage');
      });
    }

    final DocumentSnapshot taskDatabase = await FirebaseFirestore.instance
        .collection('tasks')
        .doc(widget.taskID)
        .get();
    if (taskDatabase == null) {
      print('ERROR: taskDatabase == null');
      return;
    } else {
      setState(() {
        isDone = taskDatabase.get('isDone');
        taskImage = taskDatabase.get('taskImage');
        taskTitle = taskDatabase.get('taskTitle');
        taskDescription = taskDatabase.get('taskDescription');
        taskRequirements = taskDatabase.get('taskRequirements');
        taskBenefits = taskDatabase.get('taskBenefits');
        postedDateTimestamp = taskDatabase.get('createdAt');
        deadlineDateTimestamp = taskDatabase.get('deadlineDateTimestamp');
        deadlineDate = taskDatabase.get('deadlineDate');
        var postDate = postedDateTimestamp!.toDate();
        postedDate = '${postDate.day}-${postDate.month}-${postDate.year}';
      });

        var timestampToDateTime = deadlineDateTimestamp!.toDate();
        print(timestampToDateTime);
        print(DateTime.now());
        setState((){
          _isDeadlineAvailable = timestampToDateTime.isBefore(DateTime.now());
        }
        );

    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.brown[100],
      appBar: AppBar(
        ///learn more
        automaticallyImplyLeading: false,
        // iconTheme: IconThemeData(color: Colors.lightBlue),
        ///
        elevation: 0,
        backgroundColor: Colors.brown[100],
        title: TextButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: const Text('กลับ',
              style: TextStyle(
                  color: Constant.lightBlue,
                  fontWeight: FontWeight.bold,
                  fontSize: 20)),
        ),

      ),
      body: SingleChildScrollView(
          child: Column(
        children: [
          // const SizedBox(height: 5),
          // TextButton(onPressed: (){
          //   Navigator.of(context).push(MaterialPageRoute(builder: (context) => TestScreen(),));
          // }, child: Text('To TEST SCREEN')),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                taskTitle == null ? 'NO INFO ON: taskTitle' : taskTitle!
                ,
                style: const TextStyle(
                    fontSize: 25,
                    color: Constant.lightBlue,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Image.network(taskImage != null ? taskImage!
              :
          'https://st3.depositphotos.com/23594922/31822/v/600/depositphotos_318221368-stock-illustration-missing-picture-page-for-website.jpg'
          ),
          const SizedBox(height: 15),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'อัพโหลดโดย: ',
                            style: _titleStyle,
                          ),
                          const Spacer(),
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              border: Border.all(
                                width: 2,
                                color: Colors.white,
                              ),
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                  image: NetworkImage(userImageUrl == null
                                      ? 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/2048px-No_image_available.svg.png'
                                      : userImageUrl!),
                                  fit: BoxFit.fill),
                            ),
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                authorName == null ? 'NO INFO' : authorName!,
                                style: _contentStyle,
                              ),
                              Text(
                                authorPosition == null
                                    ? 'NO INFO'
                                    : authorPosition,
                                style: _contentStyle,
                              ),
                            ],
                          ),
                        ],
                      ),
                      _dividerWidget(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'อัพโหลดเมื่อ: ',
                            style: _titleStyle,
                          ),
                          Text(
                            postedDate == null ? 'NO INFO' : postedDate!,
                            style: _contentStyle,
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'กรอบเวลา: ',
                            style: _titleStyle,
                          ),
                          Text(
                            deadlineDate == null ? 'null'
                                : deadlineDate![0]+deadlineDate![1]+deadlineDate![2]+deadlineDate![3]
                                +'-'+deadlineDate![4]+deadlineDate![5]+'-'+deadlineDate![6]+deadlineDate![7],
                            style: _contentStyle.copyWith(
                                color: Colors.red, fontWeight: FontWeight.bold),
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Center(
                          child: Text(
                        _isDeadlineAvailable
                            ? 'เลยกำหนด'
                            : 'ยังไม่เลยกำหนด',
                        style: _contentStyle.copyWith(
                            color: _isDeadlineAvailable
                                ? Colors.red
                                : Colors.green),
                      )),
                      _dividerWidget(),
                      Row(
                        children: [
                          // Text('สถานะความสมบูรณ์:', style: _titleStyle),
                          // Spacer(),
                          Row(
                            children: [
                              TextButton(
                                onPressed: () {
                                  User? user = _auth.currentUser;
                                  final _uid = user!.uid;
                                  if (_uid == widget.uploadedBy) {
                                    try {
                                      FirebaseFirestore.instance
                                          .collection('tasks')
                                          .doc(widget.taskID)
                                          .update({'isDone': true});
                                      getTaskData();
                                    } catch (e) {
                                      GlobalMethods.showErrorDialog(
                                          error: e.toString(), context: context);
                                    }
                                  } else {
                                    GlobalMethods.showErrorDialog(
                                        error:
                                        'เฉพาะผู้โพสเท่านั้นที่จะเปลี่ยนแปลงได้',
                                        context: context);
                                  }
                                },
                                child: Text(
                                  'แล้วเสร็จ',
                                  style: _contentStyle.copyWith(
                                      decoration: TextDecoration.underline),
                                ),
                              ),
                              Opacity(
                                  opacity: isDone ? 1 : 0,
                                  child: const Icon(
                                    Icons.check_box,
                                    color: Colors.green,
                                  )),
                              const SizedBox(
                                width: 10,
                              ),
                              TextButton(
                                onPressed: () {
                                  User? user = _auth.currentUser;
                                  final _uid = user!.uid;
                                  if (_uid == widget.uploadedBy) {
                                    try {
                                      FirebaseFirestore.instance
                                          .collection('tasks')
                                          .doc(widget.taskID)
                                          .update({'isDone': false});
                                      getTaskData();
                                    } catch (e) {
                                      GlobalMethods.showErrorDialog(
                                          error: e.toString(), context: context);
                                    }
                                  } else {
                                    GlobalMethods.showErrorDialog(
                                        error:
                                        'เฉพาะผู้โพสเท่านั้นที่จะเปลี่ยนแปลงได้',
                                        context: context);
                                  }
                                },
                                child: Text(
                                  'ยังไม่เสร็จ',
                                  style: _contentStyle.copyWith(
                                      decoration: TextDecoration.underline),
                                ),
                              ),
                              Opacity(
                                  opacity:
                                  isDone == false ? 1 :
                                  0
                                  ,
                                  child: const Icon(
                                    Icons.check_box,
                                    color: Colors.red,
                                  )),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      _dividerWidget(),
                      Text(
                        'รายละเอียดงาน:',
                        style: _titleStyle,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        taskDescription == null ? 'ไม่มีข้อมูลรายละเอียดงาน' : taskDescription!,
                        style: _contentStyle,
                      ),
                      _dividerWidget(),
                      Text(
                        'งานต้องการ:',
                        style: _titleStyle,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        taskRequirements == null ? 'ไม่มีข้อมูลว่างานต้องการอะไร' : taskRequirements!,
                        style: _contentStyle,
                      ),
                      _dividerWidget(),
                      Text(
                        'ประโยชน์ที่จะได้:',
                        style: _titleStyle,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        taskBenefits == null ? 'ไม่มีข้อมูลประโยชน์ที่จะได้' : taskBenefits!,
                        style: _contentStyle,
                      ),
                      const SizedBox(height: 15),
                      const SizedBox(height: 15),
                      Center(
                        child: Row(
                          children: [
                            ElevatedButton(
                              style: ButtonStyle(
                                  backgroundColor: _isCommenting
                                      ? MaterialStateProperty.all<Color>(Colors.red)
                                      : MaterialStateProperty.all<Color>(
                                          Colors.green)),
                              onPressed: () async {
                                setState(() {
                                  _isCommenting = !_isCommenting;
                                });
                              },
                              child: _isCommenting ? const Text('Cancle') : const Text('Comment'),
                            ),
                            Spacer(),
                            !_isCommenting ? SizedBox(width: 1,) : ElevatedButton(
                              child: Text('SAVE'),
                              style: ButtonStyle(
                                  backgroundColor:
                                  MaterialStateProperty.all<Color>(
                                      Colors.lightBlue)),
                              onPressed: () async {
                                ///----------------------------
                                User? user = _auth.currentUser;
                                final _uid = user!.uid;
                                var currentUserData = await FirebaseFirestore.instance
                                    .collection('users')
                                    .doc(_uid)
                                    .get();
                                ///----------------------------
                                if (_commentController.text.length <= 1) {
                                  GlobalMethods.showErrorDialog(
                                      error: 'Blank comment is not available',
                                      context: context);
                                } else {
                                  final generatedID = Uuid().v4();
                                  await FirebaseFirestore.instance
                                      .collection('tasks')
                                      .doc(widget.taskID)
                                      .update({
                                    'taskComments': FieldValue.arrayUnion([
                                      {
                                        'userID': _uid
                                        ,
                                        'name': currentUserData['name'],
                                        'userImageUrl': currentUserData['userImage'],
                                        'commentID': generatedID,
                                        'commentBody':
                                        _commentController.text,
                                        'time': Timestamp.now(),
                                      }
                                    ])
                                  });
                                  await Fluttertoast.showToast(
                                      msg: "The task has been uploaded.",
                                      toastLength: Toast.LENGTH_LONG,
                                      backgroundColor:
                                      Colors.deepOrangeAccent,
                                      fontSize: 18.0);
                                  _commentController.clear();
                                }
                                setState((){
                                  _isCommenting = false;
                                });
                              },

                            ),
                          ],
                        ),
                      ),
                      _isCommenting
                          ? Column(children: [
                              TextField(
                                maxLines: 5,
                                controller: _commentController,
                                decoration: const InputDecoration(
                                    border: OutlineInputBorder(),
                                    hintText: 'พิมพ์ความเห็นที่นี่'),
                              ),
                            ])
                          : const SizedBox(
                              height: 1,
                            ),
                      _dividerWidget(),

                      FutureBuilder<DocumentSnapshot>(
                          future: FirebaseFirestore.instance
                              .collection('tasks')
                              .doc(widget.taskID)
                              .get(),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState ==
                                ConnectionState.waiting) {
                              return const Center(child: CircularProgressIndicator());
                            }
                            else if (snapshot.connectionState ==
                                ConnectionState.done) {
                              try{print('SOLUTION0: '+snapshot.data!['taskComments'][0]['name']);} catch(e) {
                                // print(e.toString());
                                return Text('Currently, there is no comment');
                              }
                            }
                            return ListView.separated(
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                itemBuilder: (context, index) {
                                  return CommentWidget(
                                      commenterID: snapshot.data!['taskComments'][index]['userID'],
                                                      commenterName: snapshot
                                                          .data!['taskComments'][index]['name'],
                                                      commentID: snapshot
                                                          .data!['taskComments'][index]['commentID'],
                                                      commentBody: snapshot
                                                          .data!['taskComments'][index]['commentBody'],
                                                      commentImageUrl: snapshot
                                                          .data!['taskComments'][index]['userImageUrl'],
                                  );
                                },
                                separatorBuilder: (context, index) {
                                  return const Divider(
                                    thickness: 1,
                                  )
                                  ;
                                },
                                itemCount: snapshot.data!['taskComments'].length
                            );

                          })

                    ]),
              ),
            ),
          ),
        ],
      )),
    );
  }

  Widget _dividerWidget() {
    return Column(
      children: const [
        SizedBox(
          height: 3,
        ),
        Divider(
          thickness: 1,
        ),
        SizedBox(
          height: 3,
        ),
      ],
    );
  }

}
