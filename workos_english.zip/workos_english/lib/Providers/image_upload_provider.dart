import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:workos_english/constants/constant.dart';

class ImageUploadProvider extends StatefulWidget {
  // const ImageUploadProvider({required this.context});
  // final BuildContext context;

  @override
  _ImageUploadProviderState createState() => _ImageUploadProviderState();
}

class _ImageUploadProviderState extends State<ImageUploadProvider> {

  File? imageFile;
  String? imageUrl;

  void _showImageDialog() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
              title: const Text(
                'Please choose an option',
                style: TextStyle(
                    color: Constant.lightBlue, fontWeight: FontWeight.bold),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  InkWell(
                      onTap: () {
                        _getFromCamera();
                      },
                      child: Row(
                        children: const [
                          Icon(Icons.camera, color: Constant.lightBlue),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Camera',
                            style: TextStyle(color: Constant.orange),
                          ),
                        ],
                      )),
                  const SizedBox(
                    height: 15,
                  ),
                  InkWell(
                      onTap: () {
                        _getFromGallery();
                      },
                      child: Row(
                        children: const [
                          Icon(Icons.photo_album, color: Constant.lightBlue),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Gallery',
                            style: TextStyle(color: Constant.orange),
                          ),
                        ],
                      )),
                ],
              ));
        });
  }

  void _getFromGallery() async {
    PickedFile? pickedFile = await ImagePicker()
        .getImage(source: ImageSource.gallery, maxHeight: 1080, maxWidth: 1080);
    Navigator.pop(context);
    _cropImage(pickedFile!.path);
  }

  void _getFromCamera() async {
    PickedFile? pickedFile = await ImagePicker()
        .getImage(source: ImageSource.camera, maxHeight: 1080, maxWidth: 1080);
    // imageFile = File(pickedFile!.path);
    _cropImage(pickedFile!.path);
    Navigator.pop(context);
  }

  void _cropImage(filePath) async {
    File? croppedImage = await ImageCropper.cropImage(
      sourcePath: filePath,
      maxWidth: 1080,
      maxHeight: 1080,
    );
    if (croppedImage != null) {
      setState(() {
        imageFile = croppedImage;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Stack(children: [
        SizedBox(
          width: 100,
          height: 100,
          // decoration: BoxDecoration(
          //   border: Border.all(width: 1, color: Colors.white),
          //   borderRadius: BorderRadius.circular(16),
          // ),
          child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: imageFile == null
                  ? Image.network(
                  'https://st3.depositphotos.com/23594922/31822/v/600/depositphotos_318221368-stock-illustration-missing-picture-page-for-website.jpg')
                  : Image.file(imageFile!, fit: BoxFit.fill)),
        ),
        Positioned(
          top: 0,
          left: 0,
          child: InkWell(
            onTap: () {
              _showImageDialog();
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.blue,
                border: Border.all(width: 3, color: Colors.white),
              ),
              child: imageFile == null
                  ? const Icon(
                Icons.no_photography,
                color: Colors.white,
              )
                  : const Icon(
                Icons.edit,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
