import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class TestScreen extends StatefulWidget {

  @override
  _TestState createState() => _TestState();
}

class _TestState extends State<TestScreen> {
  @override
  Widget build(BuildContext context) {
    return
      FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance
              .collection('tasks')
              .doc('3736ef6f-8fff-4bab-ba0a-3e84ddd8ca6f')
              .get(),
          builder: (context, snapshot) {
            if (snapshot.connectionState ==
                ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else {
              if (snapshot.data! == null) {
                const Center(child: Text('No Comment for this task'));
              }
            }
                  return Text(snapshot.data!['taskComments'].length.toString());
          });


  }
}
