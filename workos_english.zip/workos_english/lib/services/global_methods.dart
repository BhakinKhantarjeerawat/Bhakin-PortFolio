import 'dart:io';
import 'package:flutter/material.dart';
import 'package:workos_english/constants/constant.dart';

class GlobalMethods {

  static File? imageFile;
  static String? imageUrl;

  static void showErrorDialog({required String error, required BuildContext context}) {
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Row(children: const [
            Icon(Icons.error, color: Constant.orange,),
            SizedBox(width: 10),
            Text('ERROR: ', style: TextStyle(color: Constant.orange),)
          ],),
          content: Text('$error'),
          actions: [
            TextButton(
              child: const Text('Close'),
              onPressed: () {
                Navigator.canPop(context) ? Navigator.pop(context) : null;
              },
            ),
          ],
        ),);
  }

}


