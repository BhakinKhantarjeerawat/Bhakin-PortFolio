import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:workos_english/constants/constant.dart';
import 'package:workos_english/widgets/all_workers_widget.dart';
import 'package:workos_english/widgets/drawer_widget.dart';


class AllWorkersScreen extends StatefulWidget {
  @override
  State<AllWorkersScreen> createState() => _AllWorkersScreenState();
}

class _AllWorkersScreenState extends State<AllWorkersScreen> {
  bool _isFilterEnabled = false;
  String? selectedTaskCategory;
  String? selectedAddress;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.brown[100],
      drawer: DrawerWidget(),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.brown[100],
        title: const Text('ผู้ใช้งานทุกคน', style: TextStyle(fontSize: 25),),
        iconTheme: const IconThemeData(color: Colors.white70),
      ),
      body: Column(children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            TextButton(
              child: Text(selectedTaskCategory == null ? 'Select Task' : selectedTaskCategory!),
              onPressed: (){
                _showTaskCategoryDialog(
                    size:size,
                    dialogTitle: 'เลือกสายงาน',
                    itemList: Constant.taskCategoryList);
              },),
            TextButton(
              child: Text(selectedAddress == null ? 'Select Address' : selectedAddress!),
              onPressed: (){
                _showAddressDialog(
                    size:size,
                    dialogTitle: 'เลือกจังหวัด',
                    itemList: Constant.addressList);
              },)
          ],
        ),

        _isFilterEnabled ?
        StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('users')
              .where('address', isEqualTo: selectedAddress )
              .where('position', isEqualTo: selectedTaskCategory)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState==ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.connectionState == ConnectionState.active) {
              if (snapshot.data!.docs.isNotEmpty) {
                return Expanded(
                  child: ListView.builder(
                      itemCount: snapshot.data!.docs.length,
                      itemBuilder: (BuildContext context, int index) {
                        return AllWorkersWidget(
                          userID: snapshot.data!.docs[index]['id'],
                          email: snapshot.data!.docs[index]['email'],
                          phoneNumber: snapshot.data!.docs[index]['phoneNumber'],
                          imageUrl: snapshot.data!.docs[index]['userImage'],
                          name: snapshot.data!.docs[index]['name'],
                          position: snapshot.data!.docs[index]['position'],
                        );
                      }),
                );
              } else {
                return const Center(child: Text('Currently, There is no user.'));
              }
            }
            return const Center(child: Text('Something went wrong'));
          },
        )
            :
        const Center(
            child: Text('  โปรดกดเลือกประเภทงานและจังหวัด  ',
              style: TextStyle(fontSize: 25),))
      ],),
    );
  }

  void  _showTaskCategoryDialog({
    required Size size,
    required String dialogTitle,
    required List<String> itemList}) {
    showDialog(context: context, builder: (context)
    {
      return AlertDialog(
        title: Text(dialogTitle, style: const TextStyle(color: Constant.orange),),
        content: SizedBox(
          width: size.width * 0.3,
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: itemList.length,
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () {
                    ///
                    print(itemList[index]);
                    setState((){
                      selectedTaskCategory = itemList[index];
                      _isFilterEnabled = true;
                    });
                    Navigator.pop(context);
                    ///
                  },
                  child: Row(children: [
                    Icon(Icons.check_circle_rounded, color: Colors.brown[100],),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        itemList[index],
                        style: const TextStyle(color: Constant.orange),
                      ),
                    ),

                  ],),);
              }
          ),
        ),
        actions: [
          ElevatedButton(child: const Text('Close'), onPressed: () {
            Navigator.canPop(context) ? Navigator.pop(context) : null;
          },),
          // TextButton(child: const Text('Cancle filter'), onPressed: () {},),
        ],
      );
    }
    );
  }

  void _showAddressDialog({
    required Size size,
    required String dialogTitle,
    required List<String> itemList}) {
    showDialog(context: context, builder: (context)
    {
      return AlertDialog(
        title: Text(dialogTitle, style: const TextStyle(color: Constant.orange),),
        content: SizedBox(
          width: size.width * 0.3,
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: itemList.length,
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () {
                    print(itemList[index]);
                    setState((){
                      selectedAddress = itemList[index];
                      _isFilterEnabled = true;
                    });
                    Navigator.pop(context);
                  },
                  child: Row(children: [
                    Icon(Icons.check_circle_rounded, color: Colors.brown[100],),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        itemList[index],
                        style: const TextStyle(color: Constant.orange),
                      ),
                    ),

                  ],),);
              }
          ),
        ),
        actions: [
          ElevatedButton(child: const Text('Close'), onPressed: () {
            Navigator.canPop(context) ? Navigator.pop(context) : null;
          },),
        ],
      );
    }
    );
  }

}


