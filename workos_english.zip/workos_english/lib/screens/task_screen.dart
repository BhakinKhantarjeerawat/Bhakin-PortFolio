import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:workos_english/constants/constant.dart';
import 'package:workos_english/widgets/drawer_widget.dart';
import 'package:workos_english/widgets/task_widget.dart';


class TaskScreen extends StatefulWidget {

  @override
  State<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {

  TextEditingController searchController = TextEditingController();
  TextEditingController _addressController = TextEditingController();
  TextEditingController _editingController = TextEditingController();
  List<DocumentSnapshot> shownItems = [];
  bool _isFilterEnabled = false;
  String? selectedTaskCategory;
  String? selectedAddress;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.brown[100],
      drawer: const DrawerWidget(),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.brown[100],
        title: const Text('งาน', style: TextStyle(fontSize: 25),),
        actions: [],
        iconTheme: const IconThemeData(color: Colors.white70),
      ),
        body: Column(children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              TextButton(
                child: Text(selectedTaskCategory == null ? 'Select Task' : selectedTaskCategory!),
                onPressed: (){
                  _showTaskCategoryDialog(
                      size:size,
                      dialogTitle: 'เลือกสายงาน',
                      itemList: Constant.taskCategoryList);
                },),
              TextButton(
                child: Text(selectedAddress == null ? 'Select Address' : selectedAddress!),
                onPressed: (){
                  _showAddressDialog(
                      size:size,
                      dialogTitle: 'เลือกจังหวัด',
                      itemList: Constant.addressList);
                },)
            ],
          ),

          _isFilterEnabled ?

          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('tasks')
                .where('address', isEqualTo: selectedAddress )
                .where('taskCategory', isEqualTo: selectedTaskCategory)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState==ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.connectionState == ConnectionState.active) {
                if (snapshot.data!.docs.isNotEmpty) {
                  return Expanded(
                    child: ListView.builder(
                        // shrinkWrap: true,
                        // physics: NeverScrollableScrollPhysics(),
                        itemCount: snapshot.data!.docs.length,
                        itemBuilder: (BuildContext context, int index) {
                          return TaskWidget(
                            taskID: snapshot.data!.docs[index]['taskID'],
                            taskTitle: snapshot.data!.docs[index]['taskTitle'],
                            taskDescription: snapshot.data!.docs[index]['taskDescription'],
                            taskImage: snapshot.data!.docs[index]['taskImage'],
                            uploadedBy: snapshot.data!.docs[index]['uploadedBy'],
                            isDone: snapshot.data!.docs[index]['isDone'],
                          );
                        }),
                  );
                } else {
                  return const Center(
                      child: Text('ตอนนี้ ยังไม่มีงานที่ว่า'
                    , style: TextStyle(fontSize: 25),));
                }
              }
              return const Center(child: Text('Something went wrong'));
            },
          )
              :
          const Center(
              child: Text('  โปรดกดเลือกประเภทงานและจังหวัด  ',
                style: TextStyle(fontSize: 25),))
        ],)
    );
  }
  ////////// Function Area Below //////////////
  void  _showTaskCategoryDialog({
    required Size size,
    required String dialogTitle,
    required List<String> itemList}) {
    showDialog(context: context, builder: (context)
    {
      return AlertDialog(
        title: Text(dialogTitle, style: const TextStyle(color: Constant.orange),),
        content: SizedBox(
          width: size.width * 0.3,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: itemList.length,
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  ///
                  print(itemList[index]);
                  setState((){
                    selectedTaskCategory = itemList[index];
                    _isFilterEnabled = true;
                  });
                  Navigator.pop(context);
                  ///
                },
                child: Row(children: [
                  Icon(Icons.check_circle_rounded, color: Colors.brown[100],),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      itemList[index],
                      style: const TextStyle(color: Constant.orange),
                    ),
                  ),

                ],),);
            }
          ),
        ),
        actions: [
          ElevatedButton(child: const Text('Close'), onPressed: () {
            Navigator.canPop(context) ? Navigator.pop(context) : null;
          },),
          // TextButton(child: const Text('Cancle filter'), onPressed: () {},),
        ],
      );
    }
    );
  }

  void _showAddressDialog({
    required Size size,
    required String dialogTitle,
    required List<String> itemList}) {
    showDialog(context: context, builder: (context)
    {
      return AlertDialog(
        title: Text(dialogTitle, style: const TextStyle(color: Constant.orange),),
        content: SizedBox(
          width: size.width * 0.3,
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: itemList.length,
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () {
                    print(itemList[index]);
                    setState((){
                      selectedAddress = itemList[index];
                      _isFilterEnabled = true;
                    });
                    Navigator.pop(context);
                  },
                  child: Row(children: [
                    Icon(Icons.check_circle_rounded, color: Colors.brown[100],),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        itemList[index],
                        style: const TextStyle(color: Constant.orange),
                      ),
                    ),

                  ],),);
              }
          ),
        ),
        actions: [
          ElevatedButton(child: const Text('Close'), onPressed: () {
            Navigator.canPop(context) ? Navigator.pop(context) : null;
          },),
        ],
      );
    }
    );
  }

  // Widget _showTextField(Size size, ) {
  //   return GestureDetector(
  //     onTap: () {
  //       _showTaskCategoryDialog(
  //         dialogTitle: 'Select Adress',
  //           size: size,
  //           itemList: Constant.addressList,
  //           );
  //     },
  //     child: TextFormField(
  //       enabled: false,
  //       controller: _addressController,
  //       validator: (value) {
  //         if (value!.isEmpty) {
  //           return 'Please select your address';
  //         } else {
  //           return null;
  //         }
  //       },
  //       decoration: const InputDecoration(
  //         hintText: 'Select your address',
  //         hintStyle: TextStyle(
  //             color: Colors.blue, fontWeight: FontWeight.bold),
  //       ),
  //     ),
  //   );
  // }



}


