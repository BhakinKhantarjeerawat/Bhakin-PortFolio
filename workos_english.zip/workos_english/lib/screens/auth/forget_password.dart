import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:workos_english/services/global_methods.dart';

class ForgetPassword extends StatefulWidget {
  const ForgetPassword({Key? key}) : super(key: key);

  @override
  _ForgetPasswordState createState() => _ForgetPasswordState();
}

class _ForgetPasswordState extends State<ForgetPassword> with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;
  late final TextEditingController _emailController = TextEditingController(text: '');

  final _forgetPasswordFormKey = GlobalKey<FormState>();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;


  @override
  void dispose() {
    _animationController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    _animationController = AnimationController(vsync: this, duration: const Duration(seconds: 20));
    _animation = CurvedAnimation(parent: _animationController, curve: Curves.linear)
      ..addListener(() {
        setState(() {});
      })
      ..addStatusListener((animationStatus) {
        if (animationStatus == AnimationStatus.completed) {
          _animationController.reset();
          _animationController.forward();
        }
      });
    _animationController.forward();
    super.initState();
  }

  void _submitForm() async {
    final isValid = _forgetPasswordFormKey.currentState!.validate();
    FocusScope.of(context).unfocus();
    if (isValid) {
      setState(() {
        _isLoading = true;
      });
      _forgetPasswordFormKey.currentState!.save();
      try {
        await _auth.sendPasswordResetEmail(
            email: _emailController.text.trim().toLowerCase());
        Fluttertoast.showToast(
            msg: "An Email has been sent.",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
        Navigator.canPop(context) ?  Navigator.pop(context) : null;
      } catch (error) {
        GlobalMethods.showErrorDialog(error: error.toString(), context: context);
        print('ERROR! ${error}');
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
        body: Stack(
          children: [
            CachedNetworkImage(
              imageUrl:
              'https://firebasestorage.googleapis.com/v0/b/bhakinworkos.appspot.com/o/userImages%2Fr1.jpg?alt=media&token=11e7a82d-8a79-48f2-b79c-5b9b84dfb722',
              // placeholder: (context, url) => Image.asset(
        //         'assets/images/r1.jpg',
        //         fit: BoxFit.fill,
        //       ),
              errorWidget: (context, url, error) => const Icon(Icons.error),
              width: double.infinity,
              height: double.infinity,
              fit: BoxFit.cover,
              alignment: FractionalOffset(_animation.value, 0),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: ListView(
                children: [
                  SizedBox(height: size.height * 0.1),
                  const Text(
                    'Forget Password',
                    style: TextStyle(
                        color: Colors.deepOrange,
                        fontWeight: FontWeight.bold,
                        fontSize: 30),
                  ),
                  const SizedBox(height: 10),

                  Form(
                    key: _forgetPasswordFormKey,
                    child: TextFormField(
                      // key: _forgetPasswordFormKey,
                      keyboardType: TextInputType.emailAddress,
                      controller: _emailController,
                      validator: (value) {
                        if (value!.isEmpty || !value.contains('@')) {
                          return 'Please type the valid email address';
                        } else {
                          return null;
                        }
                      },
                      decoration: const InputDecoration(
                        filled: true,
                        fillColor: Colors.white70,
                        hintText: 'Type your email here',
                        hintStyle: TextStyle(color: Colors.blue),
                      ),
                    ),
                  ),

                  const SizedBox(height:40),
                  MaterialButton(
                      onPressed: _submitForm,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      color: Colors.blue,
                      child: const Text('Reset Password', style: TextStyle(fontSize: 20, color: Colors.white),)
                  ),
                ],
              ),
            ),
          ],
        ));
  }
}
