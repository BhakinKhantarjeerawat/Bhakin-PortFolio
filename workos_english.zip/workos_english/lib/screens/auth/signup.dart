
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:workos_english/Providers/image_upload_provider.dart';
import 'package:workos_english/constants/constant.dart';
import 'package:workos_english/services/global_methods.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);
  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> with TickerProviderStateMixin {
  ///  FirebaseAuth vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;
  /// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  late AnimationController _animationController;
  late Animation<double> _animation;

  late final TextEditingController _emailController = TextEditingController(text: '');
  late final TextEditingController _passwordController = TextEditingController(text: '');
  late final TextEditingController _nameController = TextEditingController(text: '');
  late final TextEditingController _phoneController = TextEditingController(text: '');
  late final TextEditingController _FacebookGroupController = TextEditingController(text: '');
  late final TextEditingController _positionController = TextEditingController(text: '  เลือกสายงาน');
  late final TextEditingController _addressController = TextEditingController(text: '  เลือกที่อยู่');
  final _hintStyle = const TextStyle(color: Colors.deepOrange, fontWeight: FontWeight.bold);

  bool _isObscure = true;
  final _signUpFormKey = GlobalKey<FormState>();
  File? imageFile;
  String? imageUrl;

  @override
  void dispose() {
    _animationController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _nameController.dispose();
    _phoneController.dispose();
    _FacebookGroupController.dispose();
    _positionController.dispose();
    _addressController.dispose();
    super.dispose();
  }


  @override
  void initState() {
    _animationController =
        AnimationController(vsync: this, duration: const Duration(seconds: 20));
    _animation =
        CurvedAnimation(parent: _animationController, curve: Curves.linear)
          ..addListener(() {
            setState(() {});
          })
          ..addStatusListener((animationStatus) {
            if (animationStatus == AnimationStatus.completed) {
              _animationController.reset();
              _animationController.forward();
            }
          });
    _animationController.forward();
    super.initState();
  }

  void _submitFormOnSignUp() async {
    final isValid = _signUpFormKey.currentState!.validate();
    if (isValid) {
      if (imageFile == null
          || _addressController.text == '  เลือกที่อยู่'
          || _positionController.text =='  เลือกสายงาน') {
        GlobalMethods.showErrorDialog(error: '(1)รูปภาพ (2)ที่อยู่ (3)สายงาน อย่างใดอย่างหนึ่งไม่ได้ถูกเลือก.', context: context);
        return;
      }

      setState((){
        _isLoading = true;
      });

      try {
        await _auth.createUserWithEmailAndPassword(
          email: _emailController.text.trim().toLowerCase(),
          password: _passwordController.text.trim().toLowerCase(),);
        Navigator.canPop(context) ? Navigator.pop(context) : null;

        /// CloudFirestore vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        final User? user = _auth.currentUser;
        final _uid = user!.uid;
        final ref = FirebaseStorage.instance.ref().child('userImages').child(_uid + '.jpg');
        await ref.putFile(imageFile!);
        imageUrl = await ref.getDownloadURL();
        FirebaseFirestore.instance.collection('users').doc(_uid).set(
          {
            'id': _uid,
            'name': _nameController.text,
            'email': _emailController.text,
            'userImage': imageUrl,
            'phoneNumber': _phoneController.text,
            'FacebookGroup':_FacebookGroupController.text,
            'position': _positionController.text,
            'address': _addressController.text,
            'createdAt': Timestamp.now(),
          }
        );
        ///^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

      } catch (e){
        setState((){
          _isLoading = false;
        });
        GlobalMethods.showErrorDialog(error: e.toString(), context: context);
      }
    }
    setState((){
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
        body: Stack(
      children: [
        SizedBox(
          child:Image.asset('assets/images/r1.jpg', fit: BoxFit.fill,),
        width: double.infinity,
          height: double.infinity,),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ListView(
            children: [
              SizedBox(height: size.height * 0.03),
              const Text(
                'Sign Up',
                style: TextStyle(
                    color: Colors.deepOrange,
                    fontWeight: FontWeight.bold,
                    fontSize: 30),
              ),
              const SizedBox(height: 10),
              RichText(
                  text: TextSpan(children: [
                const TextSpan(
                    text: 'Already have an account?',
                    style: TextStyle(
                      color: Colors.deepOrange,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    )),
                const TextSpan(text: '   '),
                TextSpan(
                    recognizer: TapGestureRecognizer()
                      ..onTap = () => Navigator.canPop(context)
                          ? Navigator.pop(context)
                          : null,
                    text: 'Log In',
                    style: const TextStyle(
                      decoration: TextDecoration.underline,
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                      fontSize: 21,
                    ))
              ])),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Stack(children: [
                  SizedBox(
                    width: 100,
                    height: 100,
                    // decoration: BoxDecoration(
                    //   border: Border.all(width: 1, color: Colors.white),
                    //   borderRadius: BorderRadius.circular(16),
                    // ),
                    child: imageFile == null
                        ? const Icon(Icons.photo, color: Colors.deepOrange, size: 50,)
                        :
                    Image.file(imageFile!, fit: BoxFit.fill),
                  ),
                  Positioned(
                    top: 0,
                    left: 0,
                    child: InkWell(
                      onTap: () {
                        _showImageDialog();
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.blue,
                          border: Border.all(width: 3, color: Colors.white),
                        ),
                        child: imageFile == null
                            ? const Icon(
                                Icons.no_photography,
                                color: Colors.white,
                          size: 50,
                              )
                            : const Icon(
                                Icons.edit,
                                color: Colors.white,
                          size: 50,

                        ),
                      ),
                    ),
                  ),
                ]),
              ),
              Card(
                child: Form(
                  key: _signUpFormKey,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _nameController,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'กรุณาพิมพ์ชื่อ';
                          } else {
                            return null;
                          }
                        },
                        decoration:  InputDecoration(
                          hintText: '  ชื่อ',
                          hintStyle: _hintStyle,
                        ),
                      ),
                      TextFormField(
                        keyboardType: TextInputType.emailAddress,
                        controller: _emailController,
                        validator: (value) {
                          if (value!.isEmpty || !value.contains('@')) {
                            return 'รูปแบบอีเมลล์ไม่ถูกต้อง';
                          } else {
                            return null;
                          }
                        },
                        decoration: InputDecoration(
                          hintText: '  อีเมลล์',
                          hintStyle: _hintStyle,
                        ),
                      ),
                      TextFormField(
                        obscureText: _isObscure,
                        controller: _passwordController,
                        validator: (value) {
                          if (value!.isEmpty || value.length < 6) {
                            return 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร';
                          } else {
                            return null;
                          }
                        },
                        decoration: InputDecoration(
                          suffixIcon: GestureDetector(
                            onTap: () {
                              setState(() {
                                _isObscure = !_isObscure;
                              });
                            },
                            child: _isObscure
                                ? Icon(Icons.visibility, color: Colors.lightBlue,)
                                : Icon(Icons.visibility_off, color: Colors.lightBlue),
                          ),
                          hintText: '  รหัสผ่าน',
                          hintStyle: _hintStyle,
                        ),
                      ),
                      TextFormField(
                        keyboardType: TextInputType.phone,
                        controller: _phoneController,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'กรุณาพิมพ์หมายเลขโทรศัพท์';
                          } else {
                            return null;
                          }
                        },
                        decoration: InputDecoration(
                          hintText: '  หมายเลขโทรศัพท์',
                          hintStyle: _hintStyle,
                        ),
                      ),
                      TextFormField(
                        controller: _FacebookGroupController,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'กรุณาใส่ FacebookGroup Address';
                          } else {
                            return null;
                          }
                        },
                        decoration: InputDecoration(
                          hintText: '  FacebookGroup Address',
                          hintStyle: _hintStyle,
                        ),
                      ),
                      /// Position Controller
                      GestureDetector(
                        onTap: () {
                          _showTaskCategoryDialog(size: size,
                              itemList: Constant.taskCategoryList,
                              controller: _positionController);
                        },
                        child: TextFormField(
                          style: const TextStyle(color: Colors.deepOrange, fontWeight: FontWeight.bold),
                          enabled: false,
                          controller: _positionController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'กรุณาเลือกตำแหน่ง';
                            } else {
                              return null;
                            }
                          },
                        ),
                      ),
                      /// Address Controller
                      GestureDetector(
                        onTap: () {
                          _showTaskCategoryDialog(size: size,
                              itemList: Constant.addressList,
                              controller: _addressController);
                        },
                        child: TextFormField(
                          style: const TextStyle(color: Colors.deepOrange, fontWeight: FontWeight.bold),
                          enabled: false,
                          controller: _addressController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'กรุณาเลือกที่อยู่';
                            } else {
                              return null;
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 7),
              _isLoading ?
              Center(child: Container(
                  width: 50,
                  height: 70,
                  child: CircularProgressIndicator()))
                  :
              MaterialButton(
                  onPressed: _submitFormOnSignUp,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  color: Colors.blue,
                  child: const Text(
                    'Sign Up',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  )),
            ],
          ),
        ),
      ],
    ));
  }

  void _showImageDialog() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
              title: const Text(
                'Please choose an option',
                style: TextStyle(
                    color: Constant.lightBlue, fontWeight: FontWeight.bold),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  InkWell(
                      onTap: () {
                        _getFromCamera();
                      },
                      child: Row(
                        children: const [
                          Icon(Icons.camera, color: Constant.lightBlue),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Camera',
                            style: TextStyle(color: Constant.orange),
                          ),
                        ],
                      )),
                  const SizedBox(
                    height: 25,
                  ),
                  InkWell(
                      onTap: () {
                        _getFromGallery();
                      },
                      child: Row(
                        children: const [
                          Icon(Icons.photo_album, color: Constant.lightBlue),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            'Gallery',
                            style: TextStyle(color: Constant.orange),
                          ),
                        ],
                      )),
                  const SizedBox(
                    height: 25,
                  ),
                  ElevatedButton(
                    child: const Text('Close'),
                    onPressed: () {
                      Navigator.canPop(context) ? Navigator.pop(context) : null;
                    },
                  ),
                ],
              ));
        });
  }

  void _getFromGallery() async {
    PickedFile? pickedFile = await ImagePicker()
        .getImage(source: ImageSource.gallery, maxHeight: 1080, maxWidth: 1080);
    Navigator.pop(context);
    _cropImage(pickedFile!.path);
  }

  void _getFromCamera() async {
    PickedFile? pickedFile = await ImagePicker()
        .getImage(source: ImageSource.camera, maxHeight: 1080, maxWidth: 1080);
    // imageFile = File(pickedFile!.path);
    _cropImage(pickedFile!.path);
    Navigator.pop(context);
  }

  void _cropImage(filePath) async {
    File? croppedImage = await ImageCropper.cropImage(
      aspectRatioPresets: [
        CropAspectRatioPreset.ratio5x4],
      sourcePath: filePath,
      maxWidth: 1080,
      maxHeight: 1080,
      compressQuality: 25,
    );
    if (croppedImage != null) {
      setState(() {
        imageFile = croppedImage;
      });
    }
  }

  void _showTaskCategoryDialog({required Size size,
    required List<String> itemList,
    required TextEditingController controller}) {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text(
              'Please select one item below',
              style: TextStyle(color: Constant.orange),
            ),
            content: SizedBox(
              width: size.width * 0.3,
              child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: itemList.length,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        setState(() {
                          controller.text = itemList[index];
                          Navigator.pop(context);
                        });
                      },
                      child: Row(
                        children: [
                          Icon(
                            Icons.check_circle_rounded,
                            color: Colors.brown[100],
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              itemList[index],
                              style: const TextStyle(color: Constant.orange),
                            ),
                          ),
                        ],
                      ),
                    );
                  }),
            ),
            actions: [
              ElevatedButton(
                child: const Text('Close'),
                onPressed: () {
                  Navigator.canPop(context) ? Navigator.pop(context) : null;
                },
              ),
              // TextButton(child: const Text('Cancle filter'), onPressed: () {},),
            ],
          );
        });
  }
}
