import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:workos_english/screens/auth/signup.dart';
import 'package:workos_english/services/global_methods.dart';
import 'forget_password.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;
  late final TextEditingController _emailController =
      TextEditingController(text: '');
  late final TextEditingController _passwordController =
      TextEditingController(text: '');
  bool _isObscure = true;
  ///
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;
  ///
  final _loginFormKey = GlobalKey<FormState>();


  @override
  void dispose() {
    _animationController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    _animationController =
        AnimationController(vsync: this, duration: const Duration(seconds: 20));
    _animation =
        CurvedAnimation(parent: _animationController, curve: Curves.linear)
          ..addListener(() {
            setState(() {});
          })
          ..addStatusListener((animationStatus) {
            if (animationStatus == AnimationStatus.completed) {
              _animationController.reset();
              _animationController.forward();
            }
          });
    _animationController.forward();
    super.initState();
  }


  void _submitFormOnSignUp() async {
    final isValid = _loginFormKey.currentState!.validate();
    if (isValid) {
      setState((){
        _isLoading = true;
      });

      try {
        await _auth.signInWithEmailAndPassword(
          email: _emailController.text.trim().toLowerCase(),
          password: _passwordController.text.trim().toLowerCase(),);
        Navigator.canPop(context) ? Navigator.pop(context) : null;
      } catch (e){
        setState((){
          _isLoading = false;
        });
        GlobalMethods.showErrorDialog(error: e.toString(), context: context);
      }
    }
    setState((){
      _isLoading = false;
    });
  }





  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
        body: Stack(
      children: [
        // CachedNetworkImage(
        //   imageUrl:
        //       'https://firebasestorage.googleapis.com/v0/b/bhakinworkos.appspot.com/o/userImages%2Fc0.jpg?alt=media&token=a5eef7a2-37cc-4a47-b639-72ea071e4b5c',
        //   placeholder: (context, url) => Image.asset(
        //     'assets/images/r1.jpg',
        //     fit: BoxFit.fill,
        //   ),
        //   errorWidget: (context, url, error) => const Icon(Icons.error),
        //   width: double.infinity,
        //   height: double.infinity,
        //   fit: BoxFit.cover,
        //   alignment: FractionalOffset(_animation.value, 0),
        // ),
        SizedBox(
          child:Image.asset('assets/images/r1.jpg', fit: BoxFit.fill,),
          width: double.infinity,
          height: double.infinity,),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ListView(
            children: [
              SizedBox(height: size.height * 0.1),
              const Text(
                'Login',
                style: TextStyle(
                  backgroundColor: Colors.white,
                    color: Colors.deepOrange,
                    fontWeight: FontWeight.bold,
                    fontSize: 30),
              ),
              const SizedBox(height: 10),
              RichText(
                  text:  TextSpan(children: [
                const TextSpan(
                    text: 'Do not have an account?',
                    style: TextStyle(
                      backgroundColor: Colors.white,
                      color: Colors.deepOrange,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    )),
                const TextSpan(text: '   '),
                TextSpan(
                  recognizer: TapGestureRecognizer()..onTap = () => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => SignUp())),
                    text: 'Sign Up',
                    style: const TextStyle(
                      backgroundColor: Colors.white,
                      decoration: TextDecoration.underline,
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ))
              ])),
              const SizedBox(height: 20,),
              Form(
                key: _loginFormKey,
                child: Column(
                  children: [
                    TextFormField(
                      keyboardType: TextInputType.emailAddress,
                      controller: _emailController,
                      validator: (value) {
                        if (value!.isEmpty || !value.contains('@')) {
                          return 'Please type the valid email address';
                        } else {
                          return null;
                        }
                      },
                      decoration: const InputDecoration(
                        errorStyle: TextStyle(color: Colors.red, backgroundColor: Colors.white),
                        filled: true,
                        fillColor: Colors.white,
                        hintText: 'Type your email here',
                        hintStyle: TextStyle(color: Colors.deepOrange),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      obscureText: _isObscure,
                      controller: _passwordController,
                      validator: (value) {
                        if (value!.isEmpty || value.length < 6) {
                          return 'Please type the password containing atleast 6 charactors';
                        } else {
                          return null;
                        }
                      },
                      decoration: InputDecoration(
                        errorStyle: const TextStyle(color: Colors.red, backgroundColor: Colors.white),
                        filled: true,
                        fillColor: Colors.white,
                        suffixIcon: GestureDetector(
                          onTap: () {
                            setState(() {
                              _isObscure = !_isObscure;
                            });
                          },
                          child: _isObscure
                              ? Icon(Icons.visibility, color: Colors.lightBlue,)
                              : Icon(Icons.visibility_off),
                        ),
                        hintText: 'Type your password here',
                        hintStyle: const TextStyle(color: Colors.deepOrange),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height:10),
              Align(
                alignment: Alignment.bottomRight,
                child: TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => ForgetPassword()));
                    },
                    child: const Text(
                      'forget password',
                      style: TextStyle(
                          backgroundColor: Colors.white,
                          color: Colors.blue,
                          fontSize: 17,
                          decoration: TextDecoration.underline,
                          fontStyle: FontStyle.italic),
                    )),
              ),
              const SizedBox(height:20),
              MaterialButton(
                onPressed: _submitFormOnSignUp,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  color: Colors.blue,
                child: const Text('Login', style: TextStyle(fontSize: 20, color: Colors.white),)
              ),
            ],
          ),
        ),
      ],
    ));
  }
}
