import 'dart:ui';

import 'package:flutter/material.dart';

class Constant {
  static const darkBlue = Color(0xFF00325A);
  static const Color orange = Colors.deepOrangeAccent;
  static const Color lightBlue = Colors.lightBlue;
  static const appBar = Color(0xD7CCC8FF);
  static const titleStyle = TextStyle(
      fontSize: 16, color: Constant.lightBlue, fontWeight: FontWeight.bold);
  static const contentStyle = TextStyle(color: Constant.orange);

  static final List<String> jobList = [
    'Owner',
    'Share Holder',
    'Board Committee',
    'Director',
    'Manager',
    'Employee',
    'Intern',
  ];

  static final List<String> taskCategoryList = [
    'Business',
    'Programming',
    'Information Technology',
    'Human Resource',
    'Marketing',
    'Design',
    'Accounting',
    'graphic design',
    'โปรเจ็คแมเนเจอร์',
    'คนเขียนบท',
    'ถ่ายทำตัดต่อวิดิโอ',
    'พากษ์ อัด ตัดต่อเสียง',
    'เล่นดนตรี',
    'การแสดง',
    'ร้องเพลง',
    'ทำฉาก',
    'สื่อสิ่งพิมพ์',
    'จิตวิทยา ความสัมพันธ์',
  ];

  static final List<String> addressList = [
    'เชียงใหม่',
    'เชียงราย',
    'เพชรบุรี',
    'เพชรบูรณ์',
    'เลย',
    'แพร่',
    'แม่ฮ่องสอน',
    'กระบี่',
    'กรุงเทพมหานคร',
    'กาญจนบุรี',
    'กาฬสินธุ์',
    'กำแพงเพชร',
    'ขอนแก่น',
    'จันทบุรี',
    'ฉะเชิงเทรา',
    'ชลบุรี',
    'ชัยนาท',
    'ชัยภูมิ',
    'ชุมพร',
    'ตรัง',
    'ตราด',
    'ตาก',
    'นครนายก',
    'นครปฐม',
    'นครพนม',
    'นครราชสีมา',
    'นครศรีธรรมราช',
    'นครสวรรค์',
    'นนทบุรี',
    'นราธิวาส',
    'น่าน',
    'บึงกาฬ',
    'บุรีรัมย์',
    'ปทุมธานี',
    'ประจวบคีรีขันธ์',
    'ปราจีนบุรี',
    'ปัตตานี',
    'พระนครศรีอยุธยา',
    'พะเยา',
    'พังงา',
    'พัทลุง',
    'พิจิตร',
    'พิษณุโลก',
    'ภูเก็ต',
    'มหาสารคาม',
    'มุกดาหาร',
    'ยโสธร',
    'ยะลา',
    'ร้อยเอ็ด',
    'ระนอง',
    'ระยอง',
    'ราชบุรี',
    'ลพบุรี',
    'ลำปาง',
    'ลำพูน',
    'ศรีสะเกษ',
    'สกลนคร',
    'สงขลา',
    'สตูล',
    'สมุทรปราการ',
    'สมุทรสงคราม',
    'สมุทรสาคร',
    'สระแก้ว',
    'สระบุรี',
    'สิงห์บุรี',
    'สุโขทัย',
    'สุพรรณบุรี',
    'สุราษฎร์ธานี',
    'สุรินทร์',
    'หนองคาย',
    'หนองบัวลำภู',
    'อ่างทอง',
    'อำนาจเจริญ',
    'อุดรธานี',
    'อุตรดิตถ์',
    'อุทัยธานี',
    'อุบลราชธานี'
  ];
}

List<String> englishAddressList = [
  'Amnat Charoen'
  ,'Ang Thong'
  ,'Bangkok'
  ,'Bueng Kan'
  ,'Buri Ram'
  ,'Chachoengsao'
  ,'Chai Nat'
  ,'Chaiyaphum'
  ,'Chanthaburi'
  ,'Chiang Mai'
  ,'Chiang Rai'
  ,'Chon Buri'
  ,'Chumphon'
  ,'Kalasin'
  ,'Kamphaeng Phet'
  ,'Kanchanaburi'
  ,'Khon Kaen'
  ,'Krabi'
  ,'Lampang'
  ,'Lamphun'
  ,'Loei'
  ,'Lop Buri'
  ,'Mae Hong Son'
  ,'Maha Sarakham'
  ,'Mukdahan'
  ,'Nakhon Nayok'
  ,'Nakhon Pathom'
  ,'Nakhon Phanom'
  ,'Nakhon Ratchasima'
  ,'Nakhon Sawan'
  ,'Nakhon Si Thammarat'
  ,'Nan'
  ,'Narathiwat'
  ,'Nong Bua Lam Phu'
  ,'Nong Khai'
  ,'Nonthaburi'
  ,'Pathum Thani'
  ,'Pattani'
  ,'Phangnga'
  ,'Phatthalung'
  ,'Phayao'
  ,'Phetchabun'
  ,'Phetchaburi'
  ,'Phichit'
  ,'Phitsanulok'
  ,'Phra Nakhon Si Ayutthaya'
  ,'Phrae'
  ,'Phuket'
  ,'Prachin Buri'
  ,'Prachuap Khiri Khan'
  ,'Ranong'
  ,'Ratchaburi'
  ,'Rayong'
  ,'Roi Et'
  ,'Sa kaeo'
  ,'Sakon Nakhon'
  ,'Samut Prakan'
  ,'Samut Sakhon'
  ,'Samut Songkhram'
  ,'Saraburi'
  ,'Satun'
  ,'Si Sa Ket'
  ,'Sing Buri'
  ,'Songkhla'
  ,'Sukhothai'
  ,'Suphan Buri'
  ,'Surat Thani'
  ,'Surin'
  ,'Tak'
  ,'Trang'
  ,'Trat'
  ,'Ubon Ratchathani'
  ,'Udon Thani'
  ,'Uthai Thani'
  ,'Uttaradit'
  ,'Yala'
  ,'Yasothon'
];