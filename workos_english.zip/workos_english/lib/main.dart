import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:workos_english/Providers/image_upload_provider.dart';
import 'package:workos_english/user_state.dart';
import 'package:provider/provider.dart';


void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();

  @override
  Widget build(BuildContext context) {

    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if(snapshot.connectionState == ConnectionState.waiting) {
          return const MaterialApp(
            debugShowCheckedModeBanner: false,
            home: Scaffold(
              backgroundColor: Colors.lightBlueAccent,
              body: Center(child: Text('App is being initialized'))
            )
          );
        } else if (snapshot.hasError) {
          const MaterialApp(
              debugShowCheckedModeBanner: false,
              home: Scaffold(
                  body: Center(child: Text('Login Error'))
              )
          );
        }
        return MultiProvider(
            providers: [
              Provider<ImageUploadProvider>(
              create: (context) => ImageUploadProvider(),)
        ],
            child: MaterialApp(
                debugShowCheckedModeBanner: false,
                title: 'Flutter WorkOs',
            theme: ThemeData(
              scaffoldBackgroundColor: Colors.white70,
              primarySwatch: Colors.blue,
            ),
            home: UserState()
          ),
        );
      },

    );
  }
}



