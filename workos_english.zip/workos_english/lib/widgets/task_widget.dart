import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:workos_english/inner_screens/task_details.dart';
import 'package:workos_english/services/global_methods.dart';

class TaskWidget extends StatefulWidget {
   const TaskWidget({
    required this.taskTitle,
    required this.taskDescription,
    required this.taskID,
    required this.uploadedBy,
    required this.isDone,
    required this.taskImage});
  final String taskTitle;
  final String taskDescription;
  final String taskID;
  final String uploadedBy;
  final bool isDone;
  final String taskImage;


  @override
  _TaskWidgetState createState() => _TaskWidgetState();
}

class _TaskWidgetState extends State<TaskWidget> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController _confirmDeletionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 8,
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: ListTile(
        onTap: () {
          Navigator.push(context, MaterialPageRoute(
            ///
            builder: (context) => TaskDetails(
              uploadedBy: widget.uploadedBy,
              taskID: widget.taskID, )
                ///
          ));
        },
        onLongPress: _deleteDialog,
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        leading: Container(
          // padding: const EdgeInsets.only(right: 2),
          // decoration: const BoxDecoration(
          //   border: Border(
          //     right: BorderSide(width:1),
          //   )
          // ),
          child:  widget.isDone ?
            // const Icon(Icons.check, size: 20, color: Colors.green,)
            SizedBox(width: 2,)
                :
            Image.network(widget.taskImage),

        ),
        title: Text(widget.taskTitle, maxLines: 3, overflow: TextOverflow.ellipsis,),
        subtitle: Text(widget.taskDescription, maxLines: 3, overflow: TextOverflow.ellipsis,),
        // trailing: const Icon(Icons.keyboard_arrow_right),
      ),
    );
  }

  void _deleteDialog() {
    User? user = _auth.currentUser;
    final _uid = user!.uid;

    showDialog(context: context, builder: (context) {
      return AlertDialog(
        title: const Text('ถ้าต้องการยืนยันการลบ ให้พิมพ์คำว่า "delete" ในช่องข้างล่าง'),
        content: TextField(
          controller: _confirmDeletionController,
        ),
        actions: [
          TextButton(onPressed: () async {
            try{
              if (widget.uploadedBy == _uid && "delete" == _confirmDeletionController.text) {
                await FirebaseFirestore.instance.collection('tasks').doc(widget.taskID).delete();
                await Fluttertoast.showToast(
                    msg: "งานที่เลือกได้ถูกลบแล้ว",
                    toastLength: Toast.LENGTH_LONG,
                    // gravity: ToastGravity.CENTER,
                    // timeInSecForIosWeb: 1,
                    backgroundColor: Colors.deepOrangeAccent,
                    // textColor: Colors.white,
                    fontSize: 18.0
                );
                Navigator.canPop(context) ? Navigator.pop(context) : null;
              } else {
                GlobalMethods.showErrorDialog(error: 'เฉพาะผู้โพสเท่านั้นที่จะลบได้ (ต้องพิมพ์คำว่า "delete" ด้วย)',
                    context: context);
              }
            }
            catch (e) {
              GlobalMethods.showErrorDialog(error: e.toString(), context: context);
            } finally {

            }

          },
              child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const  [
              Icon(Icons.delete, color: Colors.red,),
              Text('Delete', style: TextStyle(color: Colors.red),),

            ],
          )),
          ElevatedButton(
            child: Text('ยกเลิก'),
            onPressed:  () {
              Navigator.pop(context);
            },),
        ],
      );
    });
  }

}
