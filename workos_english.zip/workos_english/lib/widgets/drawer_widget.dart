import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:workos_english/constants/constant.dart';
import 'package:workos_english/inner_screens/profile_screen.dart';
import 'package:workos_english/inner_screens/upload_task.dart';
import 'package:workos_english/screens/all_workers.dart';
import 'package:workos_english/screens/task_screen.dart';
import '../user_state.dart';

class DrawerWidget extends StatelessWidget {
  const DrawerWidget({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Drawer(child:
      ListView(children: [
        DrawerHeader(
          decoration: const BoxDecoration(color: Colors.lightBlueAccent),
          child: Column(
            children: [
              // SizedBox(
                // width: double.infinity,
                //   height: double.infinity,
                //   child: Image.network('https://i.pinimg.com/236x/5b/6e/f5/5b6ef54d17574a6c0efebfae0703704e--winter-landscape-traditional-clothes.jpg', fit: BoxFit.fill,)),
              Center(child: const Icon(Icons.home, size: 90, color: Colors.deepOrangeAccent,)),
              Text('StartUpNow', style: TextStyle(color: Colors.deepOrangeAccent, fontSize: 20),),
              // Flexible(flex: 2, child: Image.network('https://i.pinimg.com/236x/5b/6e/f5/5b6ef54d17574a6c0efebfae0703704e--winter-landscape-traditional-clothes.jpg')),
              // const SizedBox(height: 20),
              // const Flexible(
              //     child: Text('StartUpNow', style: TextStyle(color: Constant.orange, fontSize: 20)),
              // ),
              // const Text('How to use the app'),
            ],
          ),
        ),
        const SizedBox(height: 30,),
        _listTile(fct: () {_navigateToProfileScreen(context);}, icon: Icons.task_outlined, label: 'บัญชีของฉัน'),
        _listTile(fct: () {_navigateToAllTaskScreen(context);}, icon: Icons.settings_outlined, label: 'รายชื่องาน'),
        _listTile(fct: () {_navigateToAllWorkersScreen(context);}, icon: Icons.workspaces_outline, label: 'ผู้ใช้ที่ลงทะเบียน'),
        _listTile(fct: () {_navigateToAddTaskScreen(context);}, icon: Icons.add_task, label: 'อัพโหลดงาน'),
        const Divider(thickness: 2,),
        _listTile(fct: () {_logOut(context);}, icon: Icons.logout, label: 'ออกจากระบบ'),

      ],),
    );
  }

  void _navigateToProfileScreen(context) {
    FirebaseAuth _auth = FirebaseAuth.instance;
    final User? user = _auth.currentUser;
    final String uid = user!.uid;

    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => ProfileScreen(userID: uid,)
      ),
    );
  }

  void _navigateToAllWorkersScreen(context) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => AllWorkersScreen()
      ),
    );
  }

  void _navigateToAllTaskScreen(context) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => TaskScreen()
      ),
    );
  }

  void _navigateToAddTaskScreen(context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UploadTask()
      ),
    );
  }

  void _logOut(context) {
    final FirebaseAuth _auth = FirebaseAuth.instance;
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Row(children: const [
            Icon(Icons.logout, color: Constant.orange,),
            SizedBox(width: 10),
            Text('Log Out?', style: TextStyle(color: Constant.orange),)
          ],),
          actions: [
            TextButton(
              child: const Text('Cancle'),
              onPressed: () {
                Navigator.canPop(context) ? Navigator.pop(context) : null;
              },
            ),
            TextButton(
              child: const Text('Log Out'),
              onPressed: () {
              _auth.signOut();
              Navigator.canPop(context) ? Navigator.pop(context) : null;
              Navigator.push(context,
                  MaterialPageRoute(
                    builder: (context)=>UserState(),
                  ));
              },
            ),
          ],
        ));
  }


  Widget _listTile({required String label, required Function fct, required IconData icon}) {
    return ListTile(
      ///Alternative///
      // onTap: () => fct,
      ///
      onTap: () {fct();},
      leading:Icon(icon),
      title: Text(label,
                  style: const TextStyle(color: Constant.orange),),
    );
  }

}

