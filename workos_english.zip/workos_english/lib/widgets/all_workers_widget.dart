import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:workos_english/inner_screens/profile_screen.dart';

class AllWorkersWidget extends StatefulWidget {
  const AllWorkersWidget({
    required this.userID,
    required this.name,
    required this.email,
    required this.position,
    required this.phoneNumber,
    required this.imageUrl});

 final String userID;
 final String name;
 final String email;
 final String position;
 final String phoneNumber;
 final String imageUrl;



  @override
  _AllWorkersWidgetState createState() => _AllWorkersWidgetState();
}

class _AllWorkersWidgetState extends State<AllWorkersWidget> {
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 8,
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: ListTile(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ProfileScreen(userID: widget.userID,)
            ),
          );
        },
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        leading: Container(
          padding: const EdgeInsets.only(right: 6),
          // decoration: const BoxDecoration(
          //     border: Border(
          //       right: BorderSide(width:1),
          //     )
          // ),
          child: Image.network(widget.imageUrl),
        ),
        title: Text(widget.name, maxLines: 2, overflow: TextOverflow.ellipsis,),
        subtitle: Text('${widget.position}/${widget.phoneNumber}', maxLines: 2, overflow: TextOverflow.ellipsis,),
        trailing: IconButton(icon: const Icon(Icons.email), onPressed: () {
          // _mailTo();
          Navigator.push(context, MaterialPageRoute(
              builder: (context) => ProfileScreen(userID: widget.userID)
          ));
        },),
      ),
    );
  }

  void _mailTo() async {
    var mailUrl = 'mailto:${widget.email}';
    if (await canLaunch(mailUrl)) {
      await launch(mailUrl);
    } else {
      print('ERROR: The specified email can not be launched');
      throw 'ERROR: The specified email NEED REVIEWING';
    }
  }

}
