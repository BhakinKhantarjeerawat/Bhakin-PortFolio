import 'package:flutter/material.dart';
import 'package:workos_english/constants/constant.dart';
import 'package:workos_english/inner_screens/profile_screen.dart';

class CommentWidget extends StatefulWidget {
  const CommentWidget({
    required this.commenterID,
    required this.commenterName,
    required this.commentID,
    required this.commentBody,
    required this.commentImageUrl});

  final String commenterID;
  final String commenterName;
  final String  commentID;
  final String commentBody;
  final String commentImageUrl;

  @override
  State<CommentWidget> createState() => _CommentWidgetState();
}

class _CommentWidgetState extends State<CommentWidget> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        Navigator.push(context, MaterialPageRoute(
            builder: (context) => ProfileScreen(userID: widget.commenterID)
        ));
      },
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Flexible(
            child: Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                border: Border.all(
                  width: 1,
                  color: Constant.lightBlue,
                ),
                shape: BoxShape.circle,
                image: DecorationImage(
                  image: NetworkImage(
                  //     widget.commentImageUrl == null ?
                  //     'https://wattention.com/wp-content/uploads/2020/07/springs-007.jpg'
                  // :
                      widget.commentImageUrl),
                  fit: BoxFit.fill,
                ),
              ),
            ),
          ),
          const SizedBox(width: 5,),
          Flexible(
            flex: 5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.commenterName,
                  style: Constant.titleStyle,
                ),
                Text(widget.commentBody, style: Constant.contentStyle),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
