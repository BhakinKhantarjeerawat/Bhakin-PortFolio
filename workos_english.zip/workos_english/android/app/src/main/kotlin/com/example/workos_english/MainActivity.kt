package com.example.workos_english

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
